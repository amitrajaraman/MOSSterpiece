#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ld = long double;



#define mp make_pair

const int p = 998244353;

int mul(int a, int b) {
    return (1LL * a * b) % p;
}

int add(int a, int b) {
    int s = (a+b);
    if (s>=p) s-=p;
    return s;
}

int sub(int a, int b) {
    int s = (a+p-b);
    if (s>=p) s-=p;
    return s;
}

int po(int a, int deg)
{
    if (deg==0) return 1;
    if (deg%2==1) return mul(a, po(a, deg-1));
    int t = po(a, deg/2);
    return mul(t, t);
}

int inv(int n)
{
    return po(n, p-2);
}


mt19937 rnd(time(0));

/*
const int N = 1200000;

vector<int> facs(N), invfacs(N);

void init()
{
    facs[0] = 1;
    for (int i = 1; i<N; i++) facs[i] = mul(facs[i-1], i);
    invfacs[N-1] = inv(facs[N-1]);
    for (int i = N-2; i>=0; i--) invfacs[i] = mul(invfacs[i+1], i+1);
}

int C(int n, int k)
{
    if (n<k) return 0;
    if (n<0 || k<0) return 0;
    return mul(facs[n], mul(invfacs[k], invfacs[n-k]));
}

*/





struct DSU
{
    vector<int> sz;
    vector<int> parent;

    void make_set(int v) {
        parent[v] = v;
        sz[v] = 1;
    }

    int find_set(int v) {
        if (v == parent[v])
            return v;
        return parent[v] = find_set(parent[v]);
    }

    void union_sets(int a, int b) {
        a = find_set(a);
        b = find_set(b);
        if (a != b) {
            if (sz[a] < sz[b])
                swap(a, b);
            parent[b] = a;
            sz[a] += sz[b];
        }
    }

    DSU (int n)
    {
        parent.resize(n);
        sz.resize(n);
        for (int i = 0; i<n; i++) make_set(i);
    }
};


vector<int> where_setik;
vector<set<pair<int, pair<int, int>>>> setik;
vector<int> minn;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(nullptr);

    int n, m;
    cin>>n>>m;


    setik.resize(n);
    where_setik.resize(n);
    minn.resize(n);

    for (int i = 0; i<n; i++) where_setik[i] = i;
    for (int i = 0; i<m; i++)
    {
        int u, v, w;
        cin>>u>>v>>w;
        u--; v--;
        if (u>v) swap(u, v);
        if (u==0)
        {
            minn[v] = w;
        }
        else
        {
            setik[u].insert(mp(w, mp(u, v)));
            setik[v].insert(mp(w, mp(v, u)));
        }
    }

    vector<ll> answer(n);

    ll total = 0;
    for (auto it: minn) total+=it;
    if (n==2)
    {
        cout<<total; return 0;
    }

    answer[n-1] = total;

    int cur = n-1;

    set<pair<int, pair<int, int>>> best;

    for (int i = 1; i<n; i++)
    {
        auto it = *setik[i].begin();
        best.insert(mp(it.first - minn[i], it.second));
    }

    DSU dsu(n);

    while (!best.empty())
    {
        auto it = *best.begin();
        //best.erase(it);

        int u = it.second.first;
        int v = it.second.second;

        if (dsu.find_set(u)==dsu.find_set(v)) continue;

        cur--;
        total+=it.first;
        answer[cur] = total;

        if (cur==1)
        {
            for (int i = 1; i<n; i++) cout<<answer[i]<<' ';
            return 0;
        }

        int paru = dsu.find_set(u);
        int parv = dsu.find_set(v);

        int posu = where_setik[paru];
        int posv = where_setik[parv];


        int MINN = min(minn[paru], minn[parv]);

        best.erase(mp((*setik[posu].begin()).first - minn[paru], (*setik[posu].begin()).second));
        best.erase(mp((*setik[posv].begin()).first - minn[parv], (*setik[posv].begin()).second));

        dsu.union_sets(paru, parv);

        minn[paru] = MINN;
        minn[parv] = MINN;

        if (setik[posu].size()<=setik[posv].size())
        {
            for (auto it: setik[posu]) setik[posv].insert(it);
            where_setik[paru] = posv;
        }
        else
        {
            for (auto it: setik[posv]) setik[posu].insert(it);
            where_setik[parv] = posu;
        }

        int root = dsu.find_set(paru);
        int pos = where_setik[root];

        while (true)
        {
            auto it = *setik[pos].begin();
            if (dsu.find_set(it.second.first)==dsu.find_set(it.second.second))
            {
                setik[pos].erase(it);
            }
            else break;
        }

        it = *setik[pos].begin();
        best.insert(mp(it.first - minn[root], it.second));
    }
}
