// #includes {{{
#ifdef MY_DEBUG
#include "header/header.hpp"
#else
#include <bits/stdc++.h>
#endif

using namespace std;

#define REP(i,n) for(int i=0;i<(int)(n);++i)
#define RREP(i,a,b) for(int i=(int)(a);i<(int)(b);++i)
#define FOR(i,c) for(__typeof((c).begin()) i=(c).begin();i!=(c).end();++i)
#define LET(x,a) __typeof(a) x(a)
//#define IFOR(i,it,c) for(__typeof((c).begin())it=(c).begin();it!=(c).end();++it,++i)
#define ALL(c) (c).begin(), (c).end()
#define MP make_pair

#define EXIST(e,s) ((s).find(e)!=(s).end())

#define RESET(a) memset((a),0,sizeof(a))
#define SET(a) memset((a),-1,sizeof(a))
#define PB push_back
#define DEC(it,command) __typeof(command) it=command

//debug

#define whole(f,x,...) ([&](decltype((x)) whole) { return (f)(begin(whole), end(whole), ## __VA_ARGS__); })(x)

typedef long long Int;
typedef unsigned long long uInt;
typedef long double rn;

template<class T>
constexpr T inf = numeric_limits<T>::has_infinity ? numeric_limits<T>::infinity():(numeric_limits<T>::max()/2);

int __inf_ignore(){
	int t = inf<int>;
	return t;
}

typedef pair<int,int> pii;

const string nl = "\n";

#ifdef MY_DEBUG
#include"print.hpp"
#include"debug.hpp"
#endif
// }}}

//{{{ Union-Find
struct UnionFind {
	vector<int> data;
	UnionFind(int size) : data(size, -1) { }
	bool unionSet(int x, int y) {
		x = root(x); y = root(y);
		if (x != y) {
			if (data[y] < data[x]) swap(x, y);
			data[x] += data[y]; data[y] = x;
		}
		return x != y;
	}
	bool findSet(int x, int y) {
		return root(x) == root(y);
	}
	int root(int x) {
		int r;
		compress(x,r);
		return r;
	}
	int size(int x) {
		return -data[root(x)];
	}
	void compress(int x,int &r){
		if(data[x]<0){
			r=x;
			return;
		}
		compress(data[x],r);
		data[x]=r;
	}
};
//}}}

struct S{
	Int d;
	int u, v;
	Int w;
	S(Int d, int u, int v, Int w):d(d), u(u), v(v), w(w){
		
	}
};

bool operator<(const S &a, const S &b){
	return a.d > b.d;
}

void solve_small(int N, int M, vector<int> U, vector<int> V, vector<int> W){
	vector<Int> adj(N), ans(N);
	vector<vector<Int> > a(N, vector<Int>(N, inf<Int>));
	Int sum = 0;
	REP(i, M){
		if(U[i] == 0){
			adj[V[i]] = W[i];
			sum += W[i];
		}
		a[U[i]][V[i]] = a[V[i]][U[i]] = W[i];
	}
	vector<int> rs;
	for(int u = 1;u < N;u++)rs.push_back(u);
	UnionFind uf(N);
	ans[N - 1] = sum;
	for(int t = N - 1;t > 1;){
		Int diff = inf<Int>;
		int i0, j0;
		for(int i = 0;i < (int)rs.size();i++){
			for(int j = i + 1;j < (int)rs.size();j++){
				Int d = a[rs[i]][rs[j]];
				if(d == inf<Int>)continue;
				Int v = - max(adj[rs[i]], adj[rs[j]]) + d;
				if(diff > v){
					diff = v;
					i0 = i;
					j0 = j;
				}
			}
		}
		Int ru = adj[rs[i0]], rv = adj[rs[j0]];
		Int va = min(ru, rv), vb = max(ru, rv);
		sum -= vb;
		sum += a[rs[i0]][rs[j0]];
		t--;
		ans[t] = sum;
		uf.unionSet(rs[i0], rs[j0]);
		int r = uf.root(rs[i0]);
		adj[r] = va;
		vector<int> rs2;
		REP(i, rs.size()){
			if(i == i0 or i == j0) continue;
			rs2.push_back(rs[i]);
		}
		for(auto &&p:rs2){
			Int d = min(a[p][rs[i0]], a[p][rs[j0]]);
			a[r][p] = a[p][r] = d;
		}
		rs2.push_back(r);
		sort(ALL(rs2));
		swap(rs, rs2);
	}
	for(int i = 1;i < N;i++){
		cout<<ans[i];
		if(i < N - 1)cout<<" ";
	}
	cout<<endl;
}

void solve(int N, int M, vector<int> U, vector<int> V, vector<int> W){
	vector<Int> adj(N), ans(N);
	vector<pair<pair<int,int>, Int> > es;
	Int sum = 0;
	REP(i, M){
		if(U[i] == 0){
			adj[V[i]] = W[i];
			sum += W[i];
		}else{
			es.push_back({{U[i], V[i]}, W[i]});
		}
	}
	priority_queue<S> q;
	for(auto &&p:es){
		int U = p.first.first, V = p.first.second;
		Int W = p.second;
		q.push(S(-max(adj[U], adj[V]) + W, U, V, W));
	}
	UnionFind uf(N);
	ans[N - 1] = sum;
	for(int t = N - 1;t > 1;){
		int u, v;
		Int w;
		while(not q.empty()){
			auto t = q.top();
			q.pop();
			int u0 = t.u, v0 = t.v;
			Int T = -max(adj[uf.root(u0)], adj[uf.root(v0)]) + t.w;
			if(T == t.d){
				u = u0;v = v0;
				w = t.w;
				break;
			}else{
				q.push(S(T, u0, v0, t.w));
			}
		}
		Int ru = adj[uf.root(u)], rv = adj[uf.root(v)];
		Int va = min(ru, rv), vb = max(ru, rv);
		sum -= vb;
		sum += w;
		t--;
		ans[t] = sum;
		uf.unionSet(u, v);
		int r = uf.root(u);
		adj[r] = va;
	}
	for(int i = 1;i < N;i++){
		cout<<ans[i];
		if(i < N - 1)cout<<" ";
	}
	cout<<endl;
}


int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	int N, M;
	cin>>N>>M;
	vector<int> U, V, W;
	REP(i, M){
		int u, v, w;cin>>u>>v>>w;
		u--;v--;
		U.push_back(u);
		V.push_back(v);
		W.push_back(w);
	}
	if(N <= 500){
		solve_small(N, M, U, V, W);
	}else{
		solve(N, M, U, V, W);
	}
	return 0;
}
