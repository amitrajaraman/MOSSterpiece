#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <bits/stdc++.h>

using namespace std;

#define POW2(X) (1<<(X))
#define CKBIT(S,X) (((S)&POW2(X))!=0)
const double pi=acos(-1.0);
const double eps=1e-11;
template<class T> inline void ckmin(T &a,T b){ a=min(a,b); }
template<class T> inline void ckmax(T &a,T b){ a=max(a,b); }
template<class T> inline T sqr(T x){ return x*x; }
#define SIZE(A) ((int)A.size())
#define LENGTH(A) ((int)A.length())
#define MP(A,B) make_pair(A,B)
#define PB(X) push_back(X)
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define REP(i,a) for(int i=0;i<(a);++i)
#define ALL(A) A.begin(),A.end()
template<class T> int CMP(T a[],const T b[],int n) { return memcmp(a,b,n*sizeof(T)); }
template<class T> void COPY(T a[],const T b[],int n) { memcpy(a,b,n*sizeof(T)); }
template<class T> void SET(T a[],int val,int n) { memset(a,val,n*sizeof(T)); }
using uint=unsigned int;
using int64=long long;
using uint64=unsigned long long;
using ipair=pair<int,int>;
using VI=vector<int>;
using VD=vector<double>;
using VVI=vector<VI>;

struct Edge
{
	int u;
	int v;
	int w;
};

template <class T> class HBLTNode
{
public:
	int depth = 0;
	T data;
	HBLTNode<T>* left = nullptr;
	HBLTNode<T>* right = nullptr;
};

template<class T> class HBLT
{
public:
	using Node = HBLTNode<T>;
	HBLT() { root = nullptr; }
	const T& get_min() const { return root->data; }
	void clear() { root = nullptr; }
	bool empty() const { return root == nullptr; }
	HBLT<T>& insert(const T& x);
	HBLT<T>& delete_min();
	HBLT<T>& concatenate(HBLT<T>& x) { concatenate(root, x.root); x.root = nullptr; return *this; }
	Node* root = nullptr;
private:
	void concatenate(Node*& x, Node* y);
	static Node* new_node();
	static int buffer_pos;
	static vector<vector<Node>> buffer;
};
template<class T> int HBLT<T>::buffer_pos = 0;
template<class T> vector<vector<HBLTNode<T>>> HBLT<T>::buffer;

template<class T> HBLTNode<T>* HBLT<T>::new_node()
{
	if (buffer.empty() || buffer_pos >= static_cast<int>(buffer.back().size()))
	{
		int size = (buffer.empty() ? 16 : buffer.back().size() * 2);
		buffer.emplace_back(vector<Node>(size));
		buffer_pos = 0;
	}
	return &buffer.back()[buffer_pos++];
}

template<class T> void HBLT<T>::concatenate(Node*& x, Node* y)
{
	if (y == nullptr) return;
	if (x == nullptr) { x = y; return; }
	if (y->data < x->data) swap(x, y);
	concatenate(x->right, y);
	if (x->left == nullptr || x->right != nullptr && x->right->depth > x->left->depth)
	{
		swap(x->left, x->right);
		x->depth = x->left->depth + 1;
	}
}

template<class T> HBLT<T>& HBLT<T>::insert(const T& x)
{
	Node* q = new_node();
	q->data = x;
	concatenate(root, q);
	return *this;
}

template<class T> HBLT<T>& HBLT<T>::delete_min()
{
	if (root == nullptr) return *this;
	Node* L = root->left;
	Node* R = root->right;
	root = L;
	concatenate(root, R);
	return *this;
}

bool operator<(const Edge& a, const Edge& b) { return a.w<b.w; };
using Tree = HBLT<Edge>;

vector<int64> solve(int n,const vector<Edge>& edges)
{
	VI w(n);
	vector<Tree> g(n);
	for (const auto& e:edges)
		if (e.u==0 || e.v==0) w[e.u+e.v]=e.w;
		else if (e.u!=e.v) { g[e.u].insert({e.u,e.v,e.w}); g[e.v].insert({e.v,e.u,e.w}); }
	int64 total=0;
	REP(i,n) total+=w[i];
	VI f(n,-1);
	std::function<int(int)> getf=[&](int p) { return (f[p]<0)?p:(f[p]=getf(f[p])); };
	vector<int64> ret(n-1);
	ret[n-2]=total;
	set<ipair> heap;
	REP(i,n) if (!g[i].empty()) heap.insert(MP(g[i].get_min().w-w[i],i));
	REP(step,n-2)
	{
		total+=heap.begin()->first;
		ret[n-3-step]=total;
		Edge e=g[heap.begin()->second].get_min();
		int a=getf(e.u);
		assert(a==heap.begin()->second);
		int b=getf(e.v);
		assert(a!=b);
		if (!g[a].empty()) heap.erase(MP(g[a].get_min().w-w[a],a));
		if (!g[b].empty()) heap.erase(MP(g[b].get_min().w-w[b],b));
		if (w[a]<w[b]) swap(a,b);
		f[a]=b;
		g[b].concatenate(g[a]);
		while (!g[b].empty())
		{
			const Edge& e=g[b].get_min();
			if (getf(e.u)!=getf(e.v)) break;
			g[b].delete_min();
		}
		if (!g[b].empty()) heap.insert(MP(g[b].get_min().w-w[b],b));
	}
	return ret;
}

int main()
{
#ifdef _MSC_VER
	freopen("input.txt","r",stdin);
#endif
	std::ios::sync_with_stdio(false);
	int n,m;
	cin>>n>>m;
	vector<Edge> e(m);
	REP(i,m) { cin>>e[i].u>>e[i].v>>e[i].w; --e[i].u; --e[i].v; }
	auto ret=solve(n,e);
	for (int64 x:ret) printf("%lld ",x); printf("\n");
	return 0;
}

