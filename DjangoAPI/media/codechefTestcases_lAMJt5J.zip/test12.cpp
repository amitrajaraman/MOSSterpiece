#include<bits/stdc++.h>
#define ll long long
#define ull unsigned ll
#define uint unsigned
#define pii pair<int,int>
#define pll pair<ll,ll>
#define IT iterator
#define PB push_back
#define fi first
#define se second
#define For(i,j,k) for (int i=(int)(j);i<=(int)(k);i++)
#define Rep(i,j,k) for (int i=(int)(j);i>=(int)(k);i--)
#define CLR(a,v) memset(a,v,sizeof(a));
#define CPY(a,b) memcpy(a,b,sizeof(a));
#define debug puts("wzpakking")
#define y1 ysghysgsygsh
using namespace std;
const int N=300005;
int n,m,mm,co[N],val[N];
int fa[N],key[N],inT[N];
int id[N],vis[N],f[N];
struct edge{
	int x,y,v;
	bool operator <(const edge &a)const{
		return v<a.v;
	}
}e[N*2];
int get(int x){
	return x==fa[x]?x:fa[x]=get(fa[x]);
}
void DIJK(){
	int nd=n;
	For(i,1,n) fa[i]=i;
	sort(e+1,e+mm+1);
	For(i,1,mm){
		int x=get(e[i].x);
		int y=get(e[i].y);
		if (x!=y){
			++nd;
			f[x]=f[y]=nd;
			fa[x]=fa[y]=fa[nd]=nd;
			val[nd]=e[i].v;
			inT[i]=1;
		}
	}
}
void Insert(int x){
	for (;x&&!vis[x];x=f[x]) vis[x]=1;
}
int Query(int x){
	for (;!vis[x];x=f[x]);
	return val[x];
}
bool cmpA(int x,int y){
	return co[x]<co[y];
}
bool cmpB(int x,int y){
	return key[x]>key[y];
}
long long ans;
namespace LCT{
	bool rev[N];
	int ch[N][2],fa[N];
	int val[N],id[N];
	int ex[N],ey[N];
	int nd;
	void init(){
		val[0]=-(1<<30);
		For(i,1,N-1) id[i]=i;
		nd=n;
	}
	int Mn(int x,int y){
		return val[x]>val[y]?x:y;
	}
	bool isroot(int x){
		return ch[fa[x]][0]!=x&&ch[fa[x]][1]!=x;
	}
	void pushup(int x){
		id[x]=Mn(x,Mn(id[ch[x][0]],id[ch[x][1]]));
	}
	void rever(int x){
		rev[x]^=1;
		swap(ch[x][0],ch[x][1]);
	}
	void pushdown(int x){
		if (!rev[x]) return;
		if (ch[x][0]) rever(ch[x][0]);
		if (ch[x][1]) rever(ch[x][1]);
		rev[x]=0;
	}
	void rotate(int x){
		int y=fa[x],z=fa[y];
		int l=(ch[y][1]==x),r=l^1;
		if (!isroot(y)) ch[z][ch[z][1]==y]=x;
		fa[x]=z; fa[y]=x; fa[ch[x][r]]=y;
		ch[y][l]=ch[x][r]; ch[x][r]=y;
		pushup(y); pushup(x);
	}
	void Down(int x){
		if (!isroot(x)) Down(fa[x]);
		pushdown(x);
	}
	void splay(int x){
		Down(x);
		for (;!isroot(x);rotate(x)){
			int y=fa[x],z=fa[y];
			if (!isroot(y)) rotate((ch[z][1]==y)^(ch[y][1]==x)?x:y);
		}
	}
	void access(int x){
		for (int t=0;x;t=x,x=fa[x])
			splay(x),ch[x][1]=t,pushup(x);
	}
	void makeroot(int x){
		access(x);
		splay(x);
		rever(x);
	}
	void Link(int x,int y){
		makeroot(x);
		makeroot(y);
		fa[y]=x;
	}
	void Cut(int x,int y){
		makeroot(x);
		access(y);
		splay(y);
		fa[x]=ch[y][0]=0;
		pushup(y);
	}
	int findroot(int x){
		access(x);
		splay(x);
		for (;ch[x][0];x=ch[x][0]);
		splay(x);
		return x;
	}
	int Ask(int x,int y){
		makeroot(x);
		access(y);
		splay(y);
		return id[y];
	}
	void Link(int x,int y,int v){
		//cerr<<x<<' '<<y<<' '<<v<<endl;
		int p1=findroot(x);
		int p2=findroot(y);
		//cerr<<p1<<' '<<p2<<endl;
		if (p1==p2){
			int id=Ask(x,y);
			assert(val[id]>=v);
			ans-=val[id];
			Cut(ex[id],id); Cut(ey[id],id);
		}
		val[++nd]=v; id[nd]=nd;
		ex[nd]=x; ey[nd]=y;
		Link(x,nd);	Link(y,nd);
		ans+=v;
	}
}
int main(){
	scanf("%d%d",&n,&m);
	For(i,1,m){
		int x,y,v;
		scanf("%d%d%d",&x,&y,&v);
		if (x==1) co[y]=v;
		else e[++mm]=(edge){x,y,v};
	}
	DIJK();
	For(i,2,n) id[i]=i;
	sort(id+2,id+n+1,cmpA);
	For(i,2,n){
		int x=id[i];
		if (i==2) key[x]=(1<<30);
		else key[x]=Query(x)-co[x];
		Insert(x);
	}
	sort(id+2,id+n+1,cmpB);
	ans=0;
	LCT::init();
	For(i,1,mm) if (inT[i])
		LCT::Link(e[i].x,e[i].y,e[i].v);
	For(i,2,n){
		int x=id[i];
		LCT::Link(1,x,0);
		cout<<(ans+=co[x])<<' ';
	}
}
/*
可以知道边的插入顺序 
*/