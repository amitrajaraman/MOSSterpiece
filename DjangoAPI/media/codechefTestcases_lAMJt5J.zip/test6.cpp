#include <bits/stdc++.h>
using namespace std;
#define sync ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define rep(i,n) for(int i=0; i<int(n); ++i)
#define repp(i,a,n) for(int i=a; i<int(n); ++i)
#define sz(x) int((x).size())
#define pq priority_queue
#define pb push_back
#define eb emplace_back
#define mp make_pair

template<class T> std::ostream& operator<<(std::ostream& os, const std::vector<T> &input){for (auto const& i: input) {os << i << " ";}return os;}
template<class T> std::ostream& operator<<(std::ostream& os, const std::set<T> &input){for (auto const& i: input) {os << i << " ";}return os;}
template<class T, size_t n> std::ostream& operator<<(std::ostream& os, const std::array<T, n> &input){for (size_t i=0; i<n; ++i) {os << input[i] << " ";}return os;}
template<class T1, class T2> std::ostream& operator<<(std::ostream& os, const std::pair<T1,T2> &input){os << "(" << input.first << ", " << input.second << ')';return os;}
template<class T1, class T2> std::ostream& operator<<(std::ostream& os, const std::unordered_map<T1,T2> &input){for (auto const& i: input) {os << i << " ";}return os;}

void debug_out() { cerr << endl; }
template <typename Head, typename... Tail> void debug_out(Head H, Tail... T) {cerr << " " << H;debug_out(T...);}
#ifdef LOCAL
#define dbg(...) cerr << "[" << #__VA_ARGS__ << "]:", debug_out(__VA_ARGS__)
#else
#define dbg(...) 42
#endif

double startTime;
double getCurrentTime(){return ((double)clock() - startTime) / CLOCKS_PER_SEC;}

typedef long long ll;
typedef pair<int,int> pi;
typedef pair<ll,ll> pl;
typedef vector<int> vi;
typedef vector<pi> vp;
typedef vector<ll> vl;
typedef vector<vi> vvi;

// === temeplate ===

const int maxn = 1e5;
const int maxm = 2e5;


int u[maxm],v[maxm],w[maxm];

int w1[maxn + 1]; // weight from 1 to others
vp E[maxn + 1];
int n, m;

int f[maxn + 1], g[maxn + 1], G[maxn + 1];

priority_queue<pi> Q;

void dfs(int u, int fa){
	for(auto &p: E[u]){
		int v, i; tie(v,i) = p;
		if(v==fa) continue;
		f[v] = u;
		g[v] = i;
		G[v] = max(w[i], G[u]);
		dfs(v, u);
	}
}

int get(int x){
	if(f[x] == x)return x; else return f[x] = get(f[x]);
}

void update_G(int x){
	if(f[x]==1){
		G[x] = 0;
		return;
	}
	update_G(f[x]);
	G[x] = max(G[f[x]], w[g[x]]);
}
void solve(){
	cin >> n >> m;

	rep(i,n+1) E[i].clear();

	vi ei(0);
	rep(i,m){
		cin >> u[i] >> v[i] >> w[i];
		if(u[i] > v[i]) swap(u[i],v[i]);
		if(u[i] == 1){
			w1[v[i]] = w[i];
		}else{ // not contain node 1
			ei.pb(i);
		}
	}

	sort(ei.begin(), ei.end(), [&](int x,int y){
		return w[x] < w[y];
	});

	rep(i,n) f[i + 1] = i + 1;

	ll mst = 0;

	for(int i: ei){ // edge to connect others
		int U = get(u[i]), V = get(v[i]);
		if(U!=V){
			mst += w[i];
			E[u[i]].eb(v[i], i);
			E[v[i]].eb(u[i], i);
			f[U] = V;
		}
	}

	int v1 = min_element(w1 + 2, w1 + n + 1) - w1;
	mst += w1[v1];
	f[v1] = 1; g[v1] = 0; G[v1] = 0;
	dfs(v1, 1);

	// dbg(vi(f,f+n+1));

	while(sz(Q)) Q.pop();
	for(int x=2; x<=n; x++) if(x!=v1){
		Q.push(mp(G[x] - w1[x], x));
	}

	cout << mst;
	rep(_,n-2){
		int x, wx; 
		while(1){
			tie(wx, x) = Q.top(); Q.pop();
			// dbg(x, wx, G[x], w1[x]);
			update_G(x);
			if(G[x] - w1[x] == wx){
				break;
			}else{
				Q.push(mp(G[x] - w1[x], x));
			}
		}

		// dbg(x, G[x], wx);

		mst -= wx;
		int Gx = G[x];
		vi r(0);
		for(int y=x; ;y=f[y]){
			int fy = f[y];
			int gy = g[y];
			r.pb(y);
			if(w[g[y]] == Gx) break;
		}
		// dbg(r);
		for(int i=sz(r)-2; i>=0; --i){
			int p = r[i], q = r[i + 1]; // reverse p -> q 
			f[q] = p;
			g[q] = g[p];
		}
		f[x] = 1; g[x] = 0; G[x] = 0;
		// dbg(vi(f,f+n+1));dbg(vi(g,g+n+1));

		cout << " " <<  mst;
	}

	cout << endl;

}

int main(){
    sync;
    int cas = 1;
    // cin >> cas;
    rep(ca, cas) solve();
    return 0;
}