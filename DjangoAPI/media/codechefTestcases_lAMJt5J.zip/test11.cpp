#include <bits/stdc++.h>
using namespace std;

#define fi first
#define se second
#define mp make_pair
#define pb push_back
typedef pair<int, int> ii;
typedef long long ll;

const int len = 2e5+5, inf = 1e9, lg = 17;
vector<int> cho;
vector<ii> adj[len];
int par[len], block[len], st[len], en[len], cnt;
int val[len][lg], anc[len][lg], dep[len], who[len];
ii tree[4*len];

int fin(int i){
    if (i == par[i]) return i;
    return par[i] = fin(par[i]);
}

void join(int i, int j){
    i = fin(i), j = fin(j);
    if (i == j) return;

    par[i] = j;
}

struct edg{
    int a, b, c;

    bool operator < (const edg &other){ // do i need const?
        return (c < other.c);
    }
} edge[len];

void fix(int u, int p = 0){
    st[u] = ++cnt;
    anc[u][0] = p;
    for (auto v: adj[u]){
        if (v.fi == p){
            val[u][0] = v.se;
            continue;
        }

        dep[v.fi] = dep[u]+1;
        fix(v.fi, u);
    }

    en[u] = cnt;

    //printf("u = %d, st = %d, en = %d\n", u, st[u], en[u]);
}

int path(int a, int b){
    int ans = 0;
    if (dep[a] < dep[b])
        swap(a, b);

    for (int j = lg-1; j >= 0; j--)
        if (dep[anc[a][j]] >= dep[b])
            ans = max(ans, val[a][j]), a = anc[a][j];

    if (a == b)
        return ans;

    for (int j = lg-1; j >= 0; j--)
        if (anc[a][j] != anc[b][j]){
            ans = max(ans, max(val[a][j], val[b][j]));
            a = anc[a][j], b = anc[b][j];
        }

    ans = max(ans, max(val[a][0], val[b][0]));
    return ans;
}

void upd(int p, int l, int r, int i, int j, ii v){
    if (r < i || j < l)
        return;
    if (i <= l && r <= j)
        return void(tree[p] = max(tree[p], v));

    int mid = (l+r)/2;
    upd(2*p, l, mid, i, j, v);
    upd(2*p+1, mid+1, r, i, j, v);
}

ii bel(int p, int l, int r, int i){
    if (l == r)
        return tree[p];

    int mid = (l+r)/2;
    if (i <= mid)
        return max(tree[p], bel(2*p, l, mid, i));
    return max(tree[p], bel(2*p+1, mid+1, r, i));
}

/*int find_max(int u, int p = 0){
    //printf("ins find_max: u = %d, p = %d\n", u, p);
    for (auto v: adj[u]){
        if (v.fi == p || block[v.se])
            continue;
        if (v.fi == 1)
            return 0;

        //printf("%d -> %d\n", u, v.fi);
        int temp = find_max(v.fi, u);
        //printf("%d -> %d, had ans = %d\n", u, v.fi, temp);
        if (temp != -1)
            return max(temp, v.se);
    }

    return -1;
}*/

void print(int m){
    printf("tree edges:");
    for (int i = 0; i < m; i++)
        if (!block[i])
            printf(" (%d - %d)", edge[i].a, edge[i].b);
    printf("\n");
}

int main(){
    int n, m;
    scanf("%d %d", &n, &m);
    for (int i = 0; i < m; i++){
        int a, b, c;
        scanf("%d %d %d", &a, &b, &c);
        if (a > b) swap(a, b);
        edge[i].a = a, edge[i].b = b, edge[i].c = c;
    }

    sort(edge, edge+m);

    // find mst
    for (int i = 1; i <= n; i++)
        par[i] = i;
    for (int i = 0; i < m; i++)
        block[i] = 1;

    ll sum = 0;
    int root = 0;
    for (int i = 0; i < m; i++){
        int a = edge[i].a, b = edge[i].b, c = edge[i].c;
        if (a == 1 && !root){
            root = b;
            block[i] = 0;

            sum += c;
        }
        else if (a != 1 && fin(a) != fin(b)){
            join(a, b);
            block[i] = 0;

            sum += c;

            adj[a].pb(mp(b, i));
            adj[b].pb(mp(a, i));
        }
    }

    dep[root] = 1, fix(root);
    //printf("after fix\n");

    upd(1, 1, n, st[root], en[root], mp(dep[root], root));
    who[root] = root;
    //printf("after root upd\n");

    for (int j = 1; j < lg; j++)
        for (int i = 1; i <= n; i++)
            if (anc[i][j-1]){
                anc[i][j] = anc[anc[i][j-1]][j-1];
                val[i][j] = max(val[i][j-1], val[anc[i][j-1]][j-1]);
            }

    //printf("sum = %lld\n", sum), print(m);

    for (int i = 0; i < m; i++){
        int a = edge[i].a, b = edge[i].b, c = edge[i].c;
        if (a != 1 || !block[i]) continue;

        //printf("spec edge = (%d, %d)\n", a, b);
        int s1 = bel(1, 1, n, st[b]).se;
        int x = who[s1];

        //printf("cand edge = (%d, %d)\n", edge[e].a, edge[e].b);
        int e = path(b, x);
        block[e] = 1, block[i] = 0;
        cho.pb(c - edge[e].c);

        int s2 = edge[e].a;
        if (dep[edge[e].b] > dep[edge[e].a])
            s2 = edge[e].b;

        upd(1, 1, n, st[s2], en[s2], mp(dep[s2], s2));

        if (st[s2] <= st[b] && st[b] <= en[s2])
            who[s2] = b;
        else
            who[s1] = b, who[s2] = x;
    }

    sort(cho.begin(), cho.end());

    printf("%lld", sum);
    for (auto x: cho)
        sum += x, printf(" %lld", sum);
    printf("\n");
    return 0;
}
