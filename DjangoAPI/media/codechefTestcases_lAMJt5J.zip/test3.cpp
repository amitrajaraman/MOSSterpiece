#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,int> pli;
#define x first
#define y second
#define pb push_back
#define mp make_pair
template <typename T> void chkmin(T &x,T y){y<x?x=y:T();}
template <typename T> void chkmax(T &x,T y){x<y?x=y:T();}
template <typename T> void readint(T &x)
{
	int f=1;char c;x=0;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	for(;isdigit(c);c=getchar())x=x*10+(c-'0');
	x*=f;
}
const int MOD=1000000007;
inline int dmy(int x){return x>=MOD?x-MOD:x;}
inline void inc(int &x,int y){x=dmy(x+y);}
int qmi(int x,int y)
{
	int ans=1;
	for(;y;y>>=1,x=1ll*x*x%MOD)
		if(y&1)ans=1ll*ans*x%MOD;
	return ans;
}
inline int inv(int x){return qmi(x,MOD-2);}
const int MAXN=200005;

int n,m,a[MAXN];
pair<int,pii> e[MAXN];
int fa[MAXN];
int getfa(int u){return u==fa[u]?u:fa[u]=getfa(fa[u]);}
ll res[MAXN];
int x[MAXN],y[MAXN],z[MAXN];
priority_queue<pii,vector<pii>,greater<pii> > pq;
bool vis[MAXN];

int main()
{
	#ifdef LOCAL
	freopen("code.in","r",stdin);
//	freopen("code.out","w",stdout);
	#endif
	int E,u,v,c;
	readint(n),readint(E);
	while(E--)
	{
		readint(u),readint(v),readint(c);
		if(u==1)a[v]=c;
		else e[++m]=mp(c,mp(u,v));
	}
	sort(e+1,e+m+1);
	for(int i=2;i<=n;++i)fa[i]=i;
	int cnt=0;
	for(int i=1;i<=m;++i)
	{
		u=e[i].y.x,v=e[i].y.y,c=e[i].x;
		if(getfa(u)==getfa(v))continue;
		fa[getfa(u)]=getfa(v);
		x[++cnt]=u,y[cnt]=v,z[cnt]=c;
	}
	for(int i=1;i<=n-2;++i)x[i+n-2]=y[i],y[i+n-2]=x[i],z[i+n-2]=z[i];
	ll sum=0;
	for(int i=2;i<=n;++i)sum+=a[i],fa[i]=i;
	res[n-1]=sum;
	for(int i=1;i<=2*n-4;++i)pq.push(mp(z[i]-a[x[i]],i));
	for(int i=n-2;i;--i)
	{
		while(!pq.empty())
		{
			pii p=pq.top();pq.pop();
			int t=p.y;
			if(vis[t])continue;
			if(x[t]!=getfa(x[t]))
			{
				x[t]=getfa(x[t]);
				pq.push(mp(z[t]-a[x[t]],t));
				continue;
			}
			fa[x[t]]=getfa(y[t]);
			sum+=z[t]-a[x[t]];
			vis[t]=vis[t<=n-2?t+n-2:t-n+2]=1;
			break;
		}
		res[i]=sum;
	}
	for(int i=1;i<=n-1;++i)printf("%lld ",res[i]);
	return 0;
}