#include <memory.h>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <climits>
#include <cctype>
#include <cstring>
#include <climits>
#include <cmath>
#include <vector>
#include <string>
#include <memory>
#include <numeric>
#include <limits>
#include <functional>
#include <tuple>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <iostream>
#ifndef __GNUC__
#include <intrin.h>
#endif
#include <immintrin.h>

using namespace std;

#define PROFILE_START(i)    clock_t start##i = clock()
#define PROFILE_STOP(i)     fprintf(stderr, "elapsed time (" #i ") = %f\n", double(clock() - start##i) / CLOCKS_PER_SEC)

typedef long long           ll;
typedef unsigned long long  ull;

const int INF = 0x3f3f3f3f;
const ll LINF = 0x3f3f3f3f3f3f3f3fll;

struct UnionFind {
    vector<int> parent;
    vector<int> minW0;
    vector<bool> used;
#if 1
    vector<set<pair<int, int>>> S;      // (edge-weight, group-to)
#else
    vector<vector<pair<int, int>>> S;   // (edge-weight, group-to)
#endif

    UnionFind() {
    }

    explicit UnionFind(int N, int W0[]) {
        init(N, W0);
    }

    void init(int N, int W0[]) {
        parent.resize(N);
        used.assign(N, true);
        minW0.assign(W0, W0 + N);
        S.resize(N);
        for (int i = 0; i < N; i++)
            parent[i] = i;
    }

    int find(int x) {
        if (parent[x] == x)
            return x;
        return parent[x] = find(parent[x]);
    }

    int mergeGroup(int xset, int yset) {
        if (minW0[xset] < minW0[yset])
            swap(xset, yset);

        parent[xset] = yset;
        minW0[yset] = min(minW0[yset], minW0[xset]);

#if 1
        int w, gv;
        if (S[xset].size() > S[yset].size())
            swap(S[xset], S[yset]);

        for (auto& it : S[xset]) {
            tie(w, gv) = it;
            if (!used[gv])
                gv = find(gv);
            if (gv != xset && gv != yset)
                S[yset].emplace(w, gv);
        }

        while (!S[yset].empty()) {
            tie(w, gv) = *S[yset].begin();
            if (!used[gv])
                gv = find(gv);
            if (gv != xset && gv != yset)
                break;
            S[yset].erase(S[yset].begin());
        }

        used[xset] = false;
        S[xset].clear();
#else
        int minW = INF;
        int minIdx = -1;

        int w, gv;
        vector<pair<int, int>> T;
        for (auto& it : S[xset]) {
            tie(w, gv) = it;
            if (!used[gv])
                gv = find(gv);
            if (gv != xset && gv != yset) {
                if (w < minW) {
                    minW = w;
                    minIdx = int(T.size());
                }
                T.emplace_back(w, gv);
            }
        }
        for (auto& it : S[yset]) {
            tie(w, gv) = it;
            if (!used[gv])
                gv = find(gv);
            if (gv != xset && gv != yset) {
                if (w < minW) {
                    minW = w;
                    minIdx = int(T.size());
                }
                T.emplace_back(w, gv);
            }
        }
        used[xset] = false;

        //sort(T.begin(), T.end());
        //T.erase(unique(T.begin(), T.end()), T.end());
        swap(T[0], T[minIdx]);

        swap(T, S[yset]);
        S[xset].clear();
#endif

        return yset;
    }

    int merge(int x, int y) {
        int xset = find(x);
        int yset = find(y);
        if (xset == yset)
            return xset;
        return mergeGroup(xset, yset);
    }
};

const int MAXN = 100'000;
const int MAXM = 200'000;

int gN, gM;
vector<pair<int, int>> gE[MAXN + 1];     // (v, idx)
tuple<int, int, int> gUV[MAXM + 1];     // (u, v, w)

int gW0[MAXN + 1];
vector<pair<int, int>> gE2[MAXN + 1];   // (v, idx)

ll gAns[MAXN + 1];

void solve() {
    int u, v, w;
    UnionFind dsu(gN, gW0);

    ll weight = 0;
    for (int i = 0; i < gM; i++) {
        if (get<0>(gUV[i]) == 0)
            weight += get<2>(gUV[i]);
        else {
            tie(u, v, w) = gUV[i];
#if 1
            dsu.S[u].emplace(w, v);
            dsu.S[v].emplace(w, u);
#else
            dsu.S[u].emplace_back(w, v);
            dsu.S[v].emplace_back(w, u);
#endif
        }
    }
    gAns[gN - 1] = weight;

    vector<int> vecW(gN);       // [group] = weight
    set<pair<int, int>> setW;   // (weight, group)
    for (int u = 1; u < gN; u++) {
#if 0
        sort(dsu.S[u].begin(), dsu.S[u].end());
#endif

        vecW[u] = dsu.S[u].begin()->first - dsu.minW0[u];
        setW.emplace(vecW[u], u);
    }

    int gu, gv;
    for (int j = gN - 2; j > 0; j--) {
        tie(w, gv) = *setW.begin();
        gu = dsu.S[gv].begin()->second;

        gv = dsu.find(gv);
        gu = dsu.find(gu);

        if (j > 1) {
            setW.erase(make_pair(vecW[gu], gu));
            setW.erase(make_pair(vecW[gv], gv));

            int tg = dsu.mergeGroup(gu, gv);
            if (tg == gu) {
                vecW[gu] = dsu.S[gu].begin()->first - dsu.minW0[gu];
                setW.emplace(vecW[gu], gu);
            } else {
                vecW[gv] = dsu.S[gv].begin()->first - dsu.minW0[gv];
                setW.emplace(vecW[gv], gv);
            }
        }

        weight += w;
        gAns[j] = weight;
    }
}

int main(void) {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> gN >> gM;

    int u, v, w;
    for (int i = 0; i < gM; i++) {
        cin >> u >> v >> w;
        --u; --v;

        gUV[i] = make_tuple(u, v, w);
        gE[u].emplace_back(v, i);
        gE[v].emplace_back(u, i);
        if (u == 0)
            gW0[v] = w;
    }

    solve();

    cout << gAns[1];
    for (int i = 2; i < gN; i++)
        cout << ' ' << gAns[i];
    cout << endl;

    return 0;
}
