#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define vi vector<int>
#define pb push_back
#define pii pair<int,int>
#define fi first
#define se second
#define re cin>>
#define pr cout<<
#define all(x) x.begin(),x.end()


const int N=2e5+5;
const int mod=1e9+7;

int n,m;
int par[N],parEd[N];
void init(){ for(int i=1;i<=n;i++) par[i]=i;}
int get(int x){
    while(x!=par[x]) x=par[x]=par[par[x]];
    return x;
}
void join(int x, int y){
    // make x the parent of y
    x=get(x);
    y=get(y);
    if(x==y) return;
    par[y]=par[x];
}


// <n-1 number of edges are getting returned!

struct edge{int u,v,w,cost;};
struct comp{
    bool operator()(edge &e1, edge&e2){
        // return e1.cost<e2.cost;
        return e1.cost>e2.cost;
    }
};

vector<pii> adj[N];
vector<ll> res;

void solve(){
    init();
    ll sum=0;
    priority_queue<edge,vector<edge>,comp> pq;
    for(int i=2;i<=n;i++) {
        sum+=parEd[i];
        for(auto pp: adj[i])
            pq.push({i,pp.first,pp.second,pp.second-parEd[i]});
    }

    res.push_back(sum);
    while(!pq.empty()){
        edge top = pq.top();
        pq.pop();
        if(get(top.u)==get(top.v)) continue; // old edge
        if(top.cost!=top.w-parEd[get(top.u)]) {
            // the component of this edge is updated
            // add new edge!
            top.cost=(top.w-parEd[get(top.u)]); 
            pq.push(top);
            continue; 
        }
        sum+=top.cost;
        join(top.v,top.u); // since v is already connected! add u to v
        // though the edges are added again but we cant wait for the time it is added!
        for(auto pp: adj[top.u]) if(get(pp.first)!=get(top.u)) {
            pq.push({top.u,pp.first,pp.second,pp.second-parEd[get(top.u)]});
        }
        res.push_back(sum);
    }
    reverse(all(res));
}


int main(){
    cin.tie(NULL); cout.tie(NULL); ios_base::sync_with_stdio(false);
    int u,v,w;
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>u>>v>>w;
        if(u==1) parEd[v]=w;
        else if(v==1) parEd[u]=w;
        else {
            adj[u].push_back({v,w});
            adj[v].push_back({u,w});
        }
    }
    solve();
    for(auto x: res) cout<<x<<" ";
    return 0;
}
