#include <bits/stdc++.h>
#define i3 array<int,3>
#define i2 array<int,2>
#define PB push_back
#define all(x) x.begin(),x.end()
#define sz(x) ((int)x.size())
using namespace std;
typedef long long ll;
const int oo = 2e9;
const int N = 100100;
set<i3> g[N];
ll ans, res[N];
int n, m, pre[N], cost[N];
i2 st[4 * N];

int get(int x) { return (pre[x] == x ? x : pre[x] = get(pre[x])); }

void build(int v, int l, int r){
    if (l == r){
        if (l == 0)
            st[v] = {oo, l};
        else st[v] = {(*g[l].begin())[0] - cost[get(l)], l};
        return;
    }

    int md = (l + r) >> 1;

    build(v + v, l, md);
    build(v + v + 1, md + 1, r);

    st[v] = min(st[v + v], st[v + v + 1]);
}

void update(int v, int l, int r, int ps){
    if (l == r){
//        cerr << sz(g[l]) << '\n';
        g[l].erase(g[l].begin());

        if (sz(g[l]) == 0)
            st[v] = {oo, l};
        else st[v] = {(*g[l].begin())[0] - cost[get(l)], l};
        return;
    }

    int md = (l + r) >> 1;

    if (ps <= md)
        update(v + v, l, md, ps);
    else update(v + v + 1, md + 1, r, ps);

    st[v] = min(st[v + v], st[v + v + 1]);
}

void make_new(int v, int l, int r, int ps){
    if (l == r){
        st[v] = {(*g[l].begin())[0] - cost[get(l)], l};
        return;
    }

    int md = (l + r) >> 1;

    if (ps <= md)
        make_new(v + v, l, md, ps);
    else make_new(v + v + 1, md + 1, r, ps);

    st[v] = min(st[v + v], st[v + v + 1]);
}

void delt(int v, int l, int r, int ps){
    if (l == r){
        st[v] = {oo, l};
        return;
    }

    int md = (l + r) >> 1;

    if (ps <= md)
        delt(v + v, l, md, ps);
    else delt(v + v + 1, md + 1, r, ps);

    st[v] = min(st[v + v], st[v + v + 1]);
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#ifdef _LOCAL
    freopen("in.txt","r",stdin);
#endif

    cin >> n >> m;

    for (int i = 0; i < n; i++)
        pre[i] = i;

    for (int i = 0; i < m; i++){
        int x, y, w; cin >> x >> y >> w;
        x--; y--;

        if (x > y) swap(x, y);

        if (x == 0){
            cost[y] = w;
            ans += w;
        } else {
            g[x].insert({w, x, y});
            g[y].insert({w, y, x});
        }
    }

    build(1, 0, n - 1);

    res[n - 1] = ans;

    for (int cnt = n - 2; cnt > 0; cnt--){
        int now = st[1][1];

        while (1){
            i3 ed = (*g[now].begin());

            int xx = get(ed[1]), yy = get(ed[2]);

            if (xx == yy){
                update(1, 0, n - 1, now);

                now = st[1][1];

                continue;
            }

            break;
        }

        ans += st[1][0];

        i3 ed = (*g[now].begin());

        int xx = get(ed[1]), yy = get(ed[2]);

        if (sz(g[xx]) > sz(g[yy])) swap(xx, yy);

        pre[xx] = yy;
        cost[yy] = min(cost[yy], cost[xx]);

        while (sz(g[xx]) > 0){
            g[yy].insert(*g[xx].begin());
            g[xx].erase(g[xx].begin());
        }

        res[cnt] = ans;

        delt(1, 0, n - 1, xx);
        make_new(1, 0, n - 1, yy);
    }

    for (int i = 1; i < n; i++)
        cout << res[i] << " ";

    return 0;
}
