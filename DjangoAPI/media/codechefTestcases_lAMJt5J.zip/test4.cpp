#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair
#define mod 998244353 
#define For(i,n) for(int i=0;i<n;i++)
#define ff first
#define ss second
#define mem(a,b) memset(a,b,sizeof(a))
#define int long long
#define ld long double
int power_mod(int num,int g)
{
    if(g==0)return 1;
    if(g%2==1)return (num*power_mod((num*num)%mod,g/2))%mod;
    return power_mod((num*num)%mod,g/2);
}
int power(int num,int g)
{
    if(g==0)return 1;
    if(g%2==1)return (num*power((num*num),g/2));
    return power((num*num),g/2);
}
vector<pair<int,int> > vec[100005];
int a[100005],b[100005];
int find(int u) {
	if(b[u]==u)return u;
	return b[u]=find(b[u]);
}
int32_t main()
{
    #ifndef ONLINE_JUDGE
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);


    int n,m;
    cin>>n>>m;
    For(i,n)b[i+1]=i+1;
    int sum=0;
    pair<int,pair<int,int> > pa[m];
    For(i,m){
    	int u,v,w;
    	cin>>u>>v>>w;
    	pa[i]={u,{v,w}};
    	if(u==1)a[v]=w,sum+=w;
    	else if(v==1)a[u]=w,sum+=w;
    	else {
    		vec[u].pb(mp(v,w));
    		vec[v].pb(mp(u,w));
    	}
    }
    priority_queue<pair<pair<int,int>,pair<int,int> >,vector<pair<pair<int,int>,pair<int,int> > >,greater<pair<pair<int,int>,pair<int,int> > > > pq;
    For(i,m){
    	int u=pa[i].ff;
    	int v=pa[i].ss.ff;
    	int w=pa[i].ss.ss;
    	if(u==1 || v==1)continue;
    	if(a[u]>a[v])swap(u,v);
    	pq.push({{w-a[v],w},{u,v}});
    }
    vector<int> vec1;
    vec1.pb(sum);
    bool visit[n+1];
    mem(visit,false);
    while(!pq.empty()) {
    	int u=pq.top().ss.ff;
    	int v=pq.top().ss.ss;
    	int w=pq.top().ff.ss;
    	int z=pq.top().ff.ff;
    	pq.pop();
    	int pu=find(u);
    	int pv=find(v);
    	if(u==v)continue;
    	if(u!=pu || v!=pv) pq.push({{w-max(a[pu],a[pv]),w},{pu,pv}});
    	else {
    		sum+=z;
    		vec1.pb(sum);
    		if(z+a[u]==w)b[u]=v;
    		else b[v]=u;
    	}
    }
    if(vec1.size()>n-1)vec1.pop_back();
    reverse(vec1.begin(),vec1.end());
    For(i,n-1)cout<<vec1[i]<<" ";
    return 0;
}