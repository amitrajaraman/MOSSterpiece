#include <bits/stdc++.h>


#define all(v) v.begin(),v.end()
#define allr(v) v.rbegin(),v.rend()
#define fori(i,n) for(ll i=0;i<n;i++)
#define pb push_back
#define ll long long int
#define mod 998244353
#define pi pair<int,int>
#define pll pair<ll,ll>
#define mp make_pair
#define item pair<ll,int>
#define item2 pair<ll,pi>
using namespace std;
vector<tuple <ll ,int ,int> > edges;
vector<pair<ll,int>> v1weights;
struct dsu
{
	std::vector<int> p;
	int n;
	dsu(int N)
	{
		n = N;
		p.resize(n);
		iota(all(p),0);									//verices are zero indexed!!
	}
	inline int getparent(int i)
	{
		return ((p[i]==i) ? i : (p[i]= getparent(p[i])));
	}
	bool unite(int x,int y)
	{
		x = getparent(x);
		y = getparent(y);
		if(x!=y)
		{
			p[x] = y;
			return true;
		}
		return false;
	}

};
struct segtreemx
{
	int treesize;
	vector <item> values;
	item IDENTITY_ELEMENT;		//Identity element
	inline void makeSINGLE(item &t,ll a,int ind)
	{
		t= mp(a,ind);
	}
	inline void merge(item &ans,item &i1,item &i2)
	{
		ans = i1.first > i2.first ? i1 : i2;
	}
	void build(vector<ll> &a,int curr,int l,int r)
	{

		if(l==r )
		{
		    if(l< (int)a.size())
            {
                 makeSINGLE(values[curr],a[l],l);
            }
			return;
		}
		int mid = (l+r)/2;
		build(a,2*curr+1,l,mid);
		build(a,2*curr+2,mid+1,r);
		merge(values[curr],values[2*curr+1],values[2*curr + 2]);


	}
	segtreemx(int n,item identity)			//Allocate space and initialize values for seg tree
	{

		treesize=1;
		IDENTITY_ELEMENT = identity;
		while(treesize < n){treesize *=2;}
		values.assign(2*treesize,IDENTITY_ELEMENT);
	}
	segtreemx(int n,item identity,vector<ll> &a) //builds segtree using vector a
	{
		treesize=1;
		IDENTITY_ELEMENT = identity;
		while(treesize < n){treesize *=2;}
		values.assign(2*treesize,IDENTITY_ELEMENT);
		build(a,0,0,treesize-1);
	}
	void set(int i,item &newval,int curr,int l,int r)
	{
		if(l == r){values[curr] = newval; return;}
		int mid = (l+r)/2;
		(i <= mid) ? set(i,newval,2*curr+1,l,mid) : set(i,newval,2*curr+2,mid+1,r);
		merge(values[curr],values[2*curr+1],values[2*curr+2]);
	}
	inline void set(int i,ll val)       // updates values index i-> value val,converts val to req datatype if defined
	{							  // Doesnt update a[i] value
		item newval;
		makeSINGLE(newval,val,i);
		set(i,newval,0,0,treesize-1);
	}
	void segmentval(item &ans,int ql,int qr,int curr,int l,int r)
	{
		if(l > qr || ql > r){return;}
		if(l >= ql  && r <= qr)
		{
			merge(ans,ans,values[curr]);
			return;
		}
		int mid = (l+r)/2;
		segmentval(ans,ql,qr,2*curr+1,l,mid);
		segmentval(ans,ql,qr,2*curr+2,mid+1,r);
	}
	inline item segmentval(int ql,int qr)                      //gets segment value from index ql to index qr(both included)
	{
		item ans = IDENTITY_ELEMENT;
		segmentval(ans,ql,qr,0,0,treesize-1);
		return ans;
	}
};
struct segtreemn
{
	int treesize;
	vector <item2> values;
	item2 IDENTITY_ELEMENT;		//Identity element
	inline void makeSINGLE(item2 &t,item a,int ind)
	{
		t = mp(a.first,mp(a.second,ind));
	}
	inline void merge(item2 &ans,item2 &i1,item2 &i2)    // The associative function segtree is based on
	{											//Note: The merge function is used with ans and i1 pointing to same element,so
										//ans should be assigned only after finding all values of new ans
		ans = i1.first < i2.first ? i1 : i2;						//It is used as merge(ans,ans,i2)
	}
	void build(vector<item> &a,int curr,int l,int r)
	{

		if(l==r )
		{
		    if(l< (int)a.size())
            {
                 makeSINGLE(values[curr],a[l],l);
            }
			return;
		}
		int mid = (l+r)/2;
		build(a,2*curr+1,l,mid);
		build(a,2*curr+2,mid+1,r);
		merge(values[curr],values[2*curr+1],values[2*curr + 2]);


	}
	void build(int n,item2 identity)			//Allocate space and initialize values for seg tree
	{							//included in build function

		treesize=1;
		IDENTITY_ELEMENT = identity;
		while(treesize < n){treesize *=2;}
		values.assign(2*treesize,IDENTITY_ELEMENT);
	}
	void build(int n,item2 identity,vector<item> &a) //builds segtree using vector a
	{
		treesize=1;
		IDENTITY_ELEMENT = identity;
		while(treesize < n){treesize *=2;}
		values.assign(2*treesize,IDENTITY_ELEMENT);
		build(a,0,0,treesize-1);
	}
	void set(int i,item2 &newval,int curr,int l,int r)
	{
		if(l == r){values[curr] = newval; return;}
		int mid = (l+r)/2;
		(i <= mid) ? set(i,newval,2*curr+1,l,mid) : set(i,newval,2*curr+2,mid+1,r);
		merge(values[curr],values[2*curr+1],values[2*curr+2]);
	}
	inline void set(int i,item val)       // updates values index i-> value val,converts val to req datatype if defined
	{							  // Doesnt update a[i] value
		item2 newval;
		makeSINGLE(newval,val,i);
		set(i,newval,0,0,treesize-1);
	}
	void segmentval(item2 &ans,int ql,int qr,int curr,int l,int r)
	{
		if(l > qr || ql > r){return;}
		if(l >= ql  && r <= qr)
		{
			merge(ans,ans,values[curr]);
			return;
		}
		int mid = (l+r)/2;
		segmentval(ans,ql,qr,2*curr+1,l,mid);
		segmentval(ans,ql,qr,2*curr+2,mid+1,r);
	}
	inline item2 segmentval(int ql,int qr)                      //gets segment value from index ql to index qr(both included)
	{
		item2 ans = IDENTITY_ELEMENT;
		segmentval(ans,ql,qr,0,0,treesize-1);
		return ans;
	}

};

int main()
{
	//ios::sync_with_stdio(0);
	//cin.tie(0);
	int n,m;
	cin >> n >> m;
	edges.resize(m);
	v1weights.resize(n);
	item identity1 = mp((ll)-5e16,-1);
	item2 identity2 = mp((ll)5e16,mp(-1,-1));
	segtreemx tree1(n,identity1);
	vector<segtreemn> tree2(n);
	vector<vector<pair<ll,int>> > adj(n);
	fori(i,m)
	{
		ll a,b,w;
		cin >> a >> b >> w;
		get<1> (edges[i]) = a-1;
		get<2> (edges[i]) = b-1;
		get<0> (edges[i]) = w;
		if(a!=1 & b!=1)
        {
            adj[a-1].pb(mp(w,i));
            adj[b-1].pb(mp(w,i));
        }
	}
	fori(i,m)
	{
		int a = get<1>(edges[i]);
		int b = get<2>(edges[i]);
		ll w = get<0>(edges[i]);
		if(a==0) v1weights[b] = mp(w,i);
		if(b==0) v1weights[a] = mp(w,i);
	}
	for(int i= 1;i< n;i++)
	{
		tree2[i].build((int)adj[i].size(),identity2,adj[i]);
	}
	for(int i = 1; i < n;i++)
	{
		auto x = tree2[i].values[0];
		ll weight = x.first;
		tree1.set(i,v1weights[i].first - weight);
	}
	dsu F(n);
	int components = n-1;
	ll curans = 0;
	fori(i,n-1) curans += v1weights[i+1].first;
	vector<ll> ans(n);
	ans[n-1] = curans;
	while(components>1)
	{
		auto maxVal = tree1.values[0];
		int a = maxVal.second;
		auto maxEdge = tree2[a].values[0];
		//assert(maxEdge.second.first!=-1);
		int b = get<1>(edges[maxEdge.second.first]) == a ? get<2>(edges[maxEdge.second.first]) : get<1>(edges[maxEdge.second.first]);
		ll weight = tree2[a].values[0].first;
		if(F.getparent(a)!=F.getparent(b))
		{
		    if(v1weights[F.getparent(a)].first-weight == maxVal.first)
            {
                curans -= maxVal.first;
                ans[--components] = curans;
                tree2[a].set(maxEdge.second.second,mp((ll)5e16,-1));
                F.unite(a,b);
                //cout << a << " " << b << "\n";
                weight = tree2[a].values[0].first;
                ll temp = v1weights[F.getparent(a)].first-weight;
                tree1.set(a,temp);
            }
            else
            {
                tree1.set(a,v1weights[F.getparent(a)].first-weight);
            }
		}
		else
		{
	    	tree2[a].set(maxEdge.second.second,mp((ll)5e16,-1));
	    	ll temp = v1weights[F.getparent(a)].first-weight;
	    	tree1.set(a,temp);
		}
	}
	for(int i = 1; i < n; i++)
	{
		cout << ans[i] << " ";
	}

	cout << "\n";
}
