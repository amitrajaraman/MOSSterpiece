#include <bits/stdc++.h>

#define mp make_pair
#define mt make_tuple
#define fi first
#define se second
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define for1(i, n) for (int i = 1; i <= (int)(n); ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; --i)
#define fore(i, a, b) for (int i = (int)(a); i <= (int)(b); ++i)

using namespace std;

typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<pii> vpi;
typedef vector<vi> vvi;
typedef long long i64;
typedef vector<i64> vi64;
typedef vector<vi64> vvi64;
typedef pair<i64, i64> pi64;
typedef double ld;

template<class T> bool uin(T &a, T b) { return a > b ? (a = b, true) : false; }
template<class T> bool uax(T &a, T b) { return a < b ? (a = b, true) : false; }

const int maxn = 110000;
int w0[maxn];

int par[maxn], rk[maxn];
vector<pair<int*, int> > ch;
vi saveP;

void save() {
    saveP.pb(ch.size());
}

void restore() {
    while ((int)ch.size() > saveP.back()) {
        auto w = ch.back();
        *w.fi = w.se;
        ch.pop_back();
    }
    saveP.pop_back();
}

void change(int *x, int y) {
    ch.pb(mp(x, *x));
    *x = y;
}

int root(int x) {
    return par[x] == x ? x : root(par[x]);
}

void unite(int x, int y) {
    x = root(x); y = root(y);
    if (x == y) return;
    if (rk[x] > rk[y]) swap(x, y);
    if (rk[x] == rk[y]) change(&rk[y], rk[x] + 1);
    change(&par[x], y);
}

i64 ans[maxn];
i64 W = 0;
int k = 0;

struct TEdge {
    int u, v, w;

    bool operator<(const TEdge &e) const {
        return w < e.w;
    }
};

void dnc(int L, int R, const vector<TEdge> &e0, const vector<TEdge> &e1) {
    if (e0.empty() && e1.empty()) return;
    if (L > R) return;
    int M = (L + R) / 2;
    save();
    vector< vector<TEdge> > f(2), g(2);
    int p0 = 0, p1 = 0;
    i64 add[2] = {0, 0};
    while (p0 < e0.size() || p1 < e1.size()) {
        int mv;
        if (p1 == e1.size()) mv = 0;
        else if (p0 == e0.size()) mv = 1;
        else mv = (e0[p0].w + 2 * M < e1[p1].w ? 0 : 1);
        TEdge e = mv ? e1[p1] : e0[p0];
        if (root(e.u) == root(e.v)) g[mv].pb(e);
        else {
            unite(e.u, e.v);
            add[mv] += e.w;
            f[mv].pb(e);
        }
        ++(mv ? p1 : p0);
    }
    k += f[0].size();
    ans[k] = (W + add[0] + add[1] - k) / 2;
    k -= f[0].size();
    restore();
    save();
    for (TEdge e: f[0]) unite(e.u, e.v);
    W += add[0];
    k += f[0].size();
    dnc(L, M - 1, g[0], f[1]);
    W -= add[0];
    k -= f[0].size();
    restore();
    save();
    for (TEdge e: f[1]) unite(e.u, e.v);
    W += add[1];
    dnc(M + 1, R, f[0], g[1]);
    W -= add[1];
    restore();
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(10);
    cout << fixed;
#ifdef LOCAL_DEFINE
    freopen("input.txt", "rt", stdin);
#endif

    int n, m;
    cin >> n >> m;

    vector<TEdge> es, e0, e1;
    forn(i, m) {
        int u, v, w;
        cin >> u >> v >> w;
        --u; --v;
        if (u == 0) e0.pb({u, v, 2 * w + 1});
        else es.pb({u, v, 2 * w});
    }
    sort(all(es));

    forn(i, n) par[i] = i;
    for (auto w: es) {
        int x = w.u, y = w.v;
        if (root(x) == root(y)) continue;
        unite(x, y);
        e1.pb(w);
    }

    sort(all(e0));
    sort(all(e1));
    forn(i, n) par[i] = i, rk[i] = 0;
    ch.clear();
    forn(i, n) ans[i] = -1e18;
    dnc(-200001, 200001, e0, e1);
    int L = 1;
    while (L < n - 1) {
        int R = L + 1;
        while (ans[R] < -1e17) ++R;
        assert((ans[R] - ans[L]) % (R - L) == 0);
        i64 d = (ans[R] - ans[L]) / (R - L);
        fore(i, L + 1, R - 1) {
            ans[i] = ans[L] + d * (i - L);
        }
        L = R;
    }
    for1(i, n - 1) cout << ans[i] << ' ';
    cout << '\n';

#ifdef LOCAL_DEFINE
    cerr << "Time elapsed: " << 1.0 * clock() / CLOCKS_PER_SEC << " s.\n";
#endif
    return 0;
}
