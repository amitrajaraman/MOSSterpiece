#include <algorithm>
#include <iostream>
#include <vector>
#include <map>
#include <numeric>
#include <set>
#include <assert.h>

using namespace std;

const int MAX_N = 1e5 + 5;
const int MAX_L = 20; // ~ Log N
const long long MOD = 1e9 + 7;
const long long INF = 1e9 + 7;

typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<vi> vvi;

#ifdef DEBUG
#define DLOGT(x) cout << x
#define D(x) (x)
#else
#define DLOGT(x) do{}while(0)
#define D(x) do{}while(0)
#endif

#define DLOG(x) DLOGT(x << endl)
#define DBG(x) DLOG(#x << ": " << (x))

#define printA(a,L,R) FOR(i,L,R,1) cout << a[i] << (i==R-1?'\n':' ')
#define printV(a) printA(a,0,a.size())

#define LSOne(S) (S & (-S))
#define isBitSet(S, i) ((S >> i) & 1)
#define FOR(i, j, k, in) for (int i=j ; i<k ; i+=in)
#define RFOR(i, j, k, in) for (int i=j ; i>=k ; i-=in)
#define REP(i, j) FOR(i, 0, j, 1)
#define RREP(i, j) RFOR(i, j, 0, 1)

struct Edge {
    int u;
    int v;
    ll w;
};

struct Subset {
    int parent;
    int rank;
    ll minw;
};

struct UnionFind {
    vector<Subset> subsets;
    void Init(int n, const vll& srep) {
        subsets.push_back({});
        for (int i = 1; i <= n; ++i) {
            subsets.push_back({i, 0, srep[i]});
        }
    }

    int Find(int i) {
        if (subsets[i].parent != i) subsets[i].parent = Find(subsets[i].parent);
        return subsets[i].parent;
    }

    ll MinW(int i) {
        i = Find(i);
        return subsets[i].minw;
    }

    void Union(int u, int v) {
        int uroot = Find(u);
        int vroot = Find(v);
        if (subsets[uroot].rank < subsets[vroot].rank) {
            subsets[uroot].parent = vroot;
            subsets[vroot].minw = min(subsets[uroot].minw, subsets[vroot].minw);
        } else if (subsets[uroot].rank > subsets[vroot].rank) {
            subsets[vroot].parent = uroot;
            subsets[uroot].minw = min(subsets[uroot].minw, subsets[vroot].minw);
        } else {
            subsets[vroot].parent = uroot;
            subsets[uroot].rank++;
            subsets[uroot].minw = min(subsets[uroot].minw, subsets[vroot].minw);
        }
    }
};


struct Solve {
    int N, M;
    vector<Edge> E;
    UnionFind UF;
    vi cheapest;
    vll srep;

    void init() {
        cin >> N >> M;
        srep.resize(N+1, 0);

        REP(i, M) {
            int u, v, w;
            cin >> u >> v >> w;
            if (u == 1) {
                srep[v] = w;
            } else {
                E.push_back({u, v, w});
            }
        }
        UF.Init(N+1, srep);
    }

    void printSet(const set<pair<ll, int>>& ei) {
        for (auto i = ei.begin(); i != ei.end(); ++i) {
            cout << i->first << ":" << i->second << " ";
        }
    }

    void run() {
        vll ans(N, 0);
        ll weight = ans[N-1] = accumulate(srep.begin(), srep.end(), 0LL);
        vi lc;
        int numTrees = N-2;
        set<pair<ll, int>> ei;
        for (int i = 0; i < E.size(); ++i) {
            ei.insert(make_pair(E[i].w - max(srep[E[i].u], srep[E[i].v]), i));
        }
        auto it = ei.begin();
        while (it != ei.end()) {
            // printSet(ei);
            // cout << " current: " << it->first << endl;


            const Edge &e = E[it->second];
            int edge_index = it->second;
            int c1 = UF.Find(e.u);
            int c2 = UF.Find(e.v);
            if (c1 == c2) { it++; continue; }
            ll sw1 = UF.MinW(c1);
            ll sw2 = UF.MinW(c2);
            ll o = e.w - max(sw1, sw2);
            if (o != it->first) {
                // cout << "Deferring on " << it->first << ":" << edge_index << " updating to " << o << ":" << edge_index << endl;
                auto tr = it;
                it--;
                ei.erase(tr);
                ei.emplace(o, edge_index);
                it++;
                continue;
            }
            weight += o;
            UF.Union(c1, c2);
            // cout << "Added " << e.u << " - " << e.v << endl;
            ans[numTrees] = weight;
            numTrees--;
            it++;
        }
        assert(numTrees == 0);
        for (int i = 1; i < N; ++i) {
            cout << ans[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    #ifdef LOCAL
        FILE *fout = freopen("input.txt", "r", stdin);
    #endif

    int tc = 1;
    for (int t = 1; t <= tc; t++) {
        //cout << "Case #" << t  << ": ";
        Solve s;
        s.init();
        s.run();
    }
}
