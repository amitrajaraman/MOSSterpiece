#include<bits/stdc++.h>
#define ll           long long int
#define pb           push_back
#define F            first
#define S            second
using namespace std;
priority_queue<pair<int,int>> t;
void dfs(int u,int p,vector<pair<int,int>> *b,int *parent,int *val,int *a,int j)
{
    parent[u]=p;
    for(auto v:b[u])
    {
        if(v.S!=p)
        {
            t.push({max(j,v.F)-a[v.S],v.S});
            val[v.S]=v.F;
            dfs(v.S,u,b,parent,val,a,max(j,v.F));
        }
    }
}
int getval(int u,int *parent,int *val)
{
    if(u==parent[u])
        return 0;
    return max(val[u],getval(parent[u],parent,val));
}
void change_root(int u,int x,int *parent,int *val)
{
    int y=u;
    vector<int> g;
    while(val[y]!=x)
    {
        g.pb(y);
        y=parent[y];
    }
    g.pb(y);
    for(int i=g.size()-1;i;--i)
    {
        val[g[i]]=val[g[i-1]];
        parent[g[i]]=g[i-1];
    }
    parent[u]=u;
    val[u]=0;
}
int get_parent(int u,int *parent)
{
    if(u==parent[u])
        return u;
    return parent[u]=get_parent(parent[u],parent);
}
void solve2(int n,int m,vector<pair<int,int>> *g,int *a,ll *sar1)
{
    int u,v,w;
    if(n<=5)
    {
        if(n==2)
        {
            sar1[1]=a[1];
            return;
        }
        sar1[n-1]=0;
        for(int i=1;i<n;++i)
            sar1[n-1]+=a[i];
        set<pair<int,pair<int,int>>> s;
        vector<int> h[n];
        multiset<pair<int,int>> e[n];
        int parent[n],val[n];
        for(int i=1;i<n;++i)
        {
            parent[i]=i;
            h[i].pb(i);
            sort(g[i].begin(),g[i].end());
            val[i]=g[i][0].F;
            e[i].insert(g[i][0]);
            s.insert(make_pair((g[i][0].F)-a[i],make_pair(i,g[i][0].S)));
            reverse(g[i].begin(),g[i].end());
        }
        for(int i=n-2;i;--i)
        {
            auto it=s.begin();
            sar1[i]=sar1[i+1]+(it->F);
            u=(it->S).F;
            v=get_parent((it->S).S,parent);
            w=(it->F);
            s.erase(it);
            auto it1=e[v].begin();
            s.erase(s.find(make_pair((val[v])-a[v],make_pair(v,(it1->S)))));
            if(h[u].size()>h[v].size())
            {
                swap(a[u],a[v]);
                swap(u,v);
            }
            for(auto j:h[u])
            {
                while(!g[j].empty())
                {
                    auto x=g[j].back();
                    int y=get_parent(x.S,parent);
                    if((y!=v)&&(y!=u))
                    {
                        e[v].insert(x);
                        break;
                    }
                    else if((y==v)&&(!g[x.S].empty()))
                    {
                        int o=x.S;
                        auto po=g[o].back();
                        if(po.S==j)
                        {
                            e[v].erase(e[v].find(po));
                            g[o].pop_back();
                            while(!g[o].empty())
                            {
                                auto qw=g[o].back();
                                int q=get_parent(qw.S,parent);
                                if((q!=u)&&(q!=v))
                                {
                                    e[v].insert(qw);
                                    break;    
                                }
                                g[o].pop_back();
                            }
                        }
                    }
                    g[j].pop_back();
                }
                h[v].pb(j);
            }
            parent[u]=v;
            auto sarit=e[v].begin();
            val[v]=(sarit->F);
            s.insert(make_pair(val[v]-a[v],make_pair(v,(sarit->S))));
        }
        return;
    }
    sar1[n-1]=0;
    for(int i=1;i<n;++i)
        sar1[n-1]+=a[i];
    set<pair<int,pair<int,int>>> s;
    multiset<pair<int,int>> e[n];
    int parent[n],val[n];
    for(int i=1;i<n;++i)
    {
        parent[i]=i;
        for(auto j:g[i])
        {
            e[i].insert(j);
        }
        auto it=e[i].begin();
        val[i]=(it->F);
        s.insert(make_pair((val[i])-a[i],make_pair(i,(it->S))));
        reverse(g[i].begin(),g[i].end());
    }
    for(int i=n-2;i;--i)
    {
        auto it=s.begin();
        sar1[i]=sar1[i+1]+(it->F);
        u=(it->S).F;
        v=get_parent((it->S).S,parent);
        w=(it->F);
        s.erase(it);
        auto it1=e[v].begin();
        s.erase(s.find(make_pair((val[v])-a[v],make_pair(v,(it1->S)))));
        if(e[u].size()>e[v].size())
        {
            swap(u,v);
            swap(a[u],a[v]);
        }
        parent[u]=v;
        auto sarit=e[v].begin();
        while(!e[u].empty())
        {
            sarit=e[u].begin();
            int x=get_parent(sarit->S,parent);
            if(x!=v)
            {
                e[v].insert(*sarit);
                e[u].erase(sarit);
            }
            else
            {
                e[u].erase(*sarit);
            }
        }
        while(1)
        {
            sarit=e[v].begin();
            int x=get_parent(sarit->S,parent);
            if(x!=v)
                break;
            e[v].erase(*sarit);
        }
        val[v]=(sarit->F);
        s.insert(make_pair(val[v]-a[v],make_pair(v,(sarit->S))));
    }
}
void solve1(int n,int m,vector<pair<int,int>> *g,int *a,ll *sar,int mx,int mv)
{
    int u,v,w;
    vector<pair<int,int>> b[n];
	bool tree[n]={0};
	set<pair<int,pair<int,int>>> s;
	for(auto j:g[1])
	    s.insert(make_pair(j.F,make_pair(1,j.S)));
	tree[1]=1;
	ll wtree=mx;
	for(int i=2;i<n;++i)
	{
	    set<pair<int,pair<int,int>>>::iterator it;
	    while(1)
	    {
	        it=s.end();--it;
	        if(!tree[(it->S).S])
	            break;
	        s.erase(it);
	    }
	    u=(it->S).S;
	    v=(it->S).F;
	    w=(it->F);
	    wtree+=(it->F);
	    tree[u]=1;
	    b[u].pb({w,v});
	    b[v].pb({w,u});
	    for(auto x:g[u])
	    {
	        if(!tree[x.S])
	            s.insert(make_pair(x.F,make_pair(u,x.S)));
	    }
	}
	int parent[n],val[n];
	dfs(mv,mv,b,parent,val,a,0);
	sar[1]=wtree;
	for(int i=2;i<n;++i)
	{
	    while(1)
	    {
	        auto ch=t.top();
	        t.pop();
	        u=ch.S;
	        v=getval(u,parent,val)-a[u];
	        if(ch.F==v)
	        {
	            break;
	        }
	        else
	        {
	            ch.F=v;
	            t.push(ch);
	        }
	    }
	    wtree-=v;
	    change_root(u,v+a[u],parent,val);
	    sar[i]=wtree;
	}
}
int main()
{
	ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
	int n,m,u,v,w;
	cin>>n>>m;
	int mx=1e9,mv=0;
	vector<pair<int,int>> g[n];
	int a[n];
	for(int i=0;i<m;++i)
	{
	    cin>>u>>v>>w;
	    --u;--v;
	    if(u&&v)
	    {
    	    g[u].pb({w,v});
    	    g[v].pb({w,u});
	    }
	    else
	    {
	        a[max(u,v)]=w;
	        if(w<mx)
	        {
	            mx=w;
	            mv=max(u,v);
	        }
	    }
	}
	ll sar[n],sar1[n];
	solve1(n,m,g,a,sar,mx,mv);
	if(n<=500)
	{
	    solve2(n,m,g,a,sar1);
	    for(int i=1;i<n;++i)
	        sar[i]=min(sar[i],sar1[i]);
	}
	for(int i=1;i<n;++i)
	    cout<<sar[i]<<" ";
	return 0;
}