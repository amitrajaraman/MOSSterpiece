#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mkp make_pair
#define rint register int
#define INF ((1 << 30) - 1)
#define FI(n) FastIO::read(n)
#define FO(n) FastIO::write(n)
#define Pair pair < int, int >
#define ull unsigned long long
#define mst(a,b) memset(a,b,sizeof(a))
#define foR(i, k, j) for(rint i = (k); i >= (j); i--)
#define For(i, k, j) for(rint i = (k); i <= (j); i++)
#define Foe(i, u) for(rint i = lst[u], v = e[i].v; i; i = e[i].nxt, v = e[i].v)
#define IOS ios::sync_with_stdio(0), cin.tie(0), cout.tie(0)
#define Fin(s) freopen(s, "r", stdin)
#define Fout(s) freopen(s, "w", stdout)
#define file(s) Fin(s".in"), Fout(s".out")
#define int long long
const int P = 998244353; //
using namespace std;
inline void ckmax(int &a, int b) {a = max(a, b);}
inline void ckmin(int &a, int b) {a = min(a, b);}
inline void mulmod(int &a, int b) {a = 1ll * a * b % P;}
inline void addmod(int &a, int b) {int t = a + b; a = (t >= P ? t - P : t); }
inline int ksm(int a, int b) {int ans=1; for(;b;b>>=1) {if(b&1) ans=1ll*ans*a%P;a=1ll*a*a%P;}return ans;}
inline int inv(int a) {return ksm(a, P-2);}

inline void printarray(int *a, int n) {For(i, 1, n) fprintf(stderr, "%d ", a[i]); fprintf(stderr, "\n");}
namespace FastIO {
    const int SIZE=1<<16; char buf[SIZE], obuf[SIZE], str[64]; int bi=SIZE, bn=SIZE, opt;
    int read(char *s) {
        while (bn) {for (;bi<bn&&buf[bi]<=' ';bi++);if (bi<bn) break; bn=fread(buf,1,SIZE,stdin),bi=0;}
        int sn=0;while (bn) {for (;bi<bn&&buf[bi]>' ';bi++) s[sn++]=buf[bi];if (bi<bn) break; bn=fread(buf,1,SIZE,stdin),bi=0;}s[sn]=0;return sn;
    }
    bool read(int& x) {if(x)x=0;int bf=0,n=read(str); if(!n) return 0; int i=0; if (str[i]=='-') bf=1,i=1; for(x=0;i<n;i++) x=x*10+str[i]-'0'; if(bf) x=-x; return 1;}
    void write(int x) {
        if(!x) obuf[opt++] = '0'; else {if(x<0) obuf[opt++]='-',x=-x;int sn=0; while(x)str[sn++]=x%10+'0',x/=10;for (int i=sn-1;i>=0;i--) obuf[opt++]=str[i];}
        if (opt>=(SIZE>>1)){fwrite(obuf, 1, opt, stdout); opt=0;}
    }
    void write(char x) {obuf[opt++]=x;if (opt>=(SIZE>>1)){fwrite(obuf, 1, opt, stdout); opt=0;}}
    void Fflush() { if (opt) fwrite(obuf, 1, opt, stdout); opt=0;}
};
inline int read() {int x; FI(x); return x;}
const int MAXN = 2e5 + 5;
int n, m, val[MAXN], ans[MAXN];
struct Edge {
	int u, v, w; 
}e[MAXN];
struct Eid {
	int x; Eid(int tx) : x(tx) {}
	bool operator < (const Eid &b) const {
		if(e[x].w != e[b.x].w) return e[x].w < e[b.x].w;
		return x < b.x;
	}
};
struct DSU {
	int f[MAXN];
	DSU() {For(i, 0, MAXN-5) f[i] = i;}
	inline int find(int x) {
		while(x != f[x]) x = f[x] = f[f[x]];
		return x;
	}
	inline void merge(int x, int y) {
		x = find(x), y = find(y);
		if(x != y) f[y] = x;
	}
}d1, d2;
 
struct Node {
	int id, val;
	Node(int x, int y) : id(x), val(y) {}
	bool operator < (const Node &b) const {
		if(val != b.val) return val < b.val;
		return id < b.id;
	}
};

set < Eid > s[MAXN];
set < Node > t;

signed main()
{
    #ifndef ONLINE_JUDGE
        file("pro");
    #endif
    n = read(), m = read();
    For(i, 1, m) {
    	e[i].u = read(), e[i].v = read(), e[i].w = read();
    	if(e[i].u > e[i].v) swap(e[i].u, e[i].v);
    	if(e[i].u == 1) val[e[i].v] = e[i].w, ans[n - 1] += e[i].w;
    	else s[e[i].u].insert(Eid(i)), s[e[i].v].insert(Eid(i));
	}
	For(i, 2, n) {
//		cerr << e[s[i].begin()->x].w - val[i] << endl;
		t.insert(Node(i, e[s[i].begin()->x].w - val[i]));
	}
//	For(i, 1, n) {
//		cerr << s[i].size() << endl;
//	}
	
	foR(i, n - 2, 1) {
		Node it = *t.begin();
		ans[i] = ans[i + 1] + it.val;
		assert(d2.find(it.id) == d2.find(d1.find(it.id)));
		int tmp = s[d2.find(it.id)].begin()->x, u = e[tmp].u, v = e[tmp].v;
//		cerr << it.id << ' ' << it.val << ' ' << u << ' ' << v << endl;
		if(t.find(Node(d1.find(u), e[tmp].w - val[d1.find(u)])) != t.end()) t.erase(Node(d1.find(u), e[tmp].w - val[d1.find(u)]));
		if(t.find(Node(d1.find(v), e[tmp].w - val[d1.find(v)])) != t.end()) t.erase(Node(d1.find(v), e[tmp].w - val[d1.find(v)]));
		if(d1.find(it.id) == d1.find(u)) d1.merge(v, u);
		else d1.merge(u, v);
		if(s[d2.find(u)].size() >= s[d2.find(v)].size()) {
			for(auto it : s[d2.find(v)]) s[d2.find(u)].insert(it);
			d2.merge(u, v); s[d2.find(u)].erase(Eid(tmp));
			while(s[d2.find(u)].size() && d1.find(e[s[d2.find(u)].begin()->x].u) == d1.find(e[s[d2.find(u)].begin()->x].v)) {
				s[d2.find(u)].erase(s[d2.find(u)].begin());
			}
			t.insert(Node(d1.find(u), e[s[d2.find(u)].begin()->x].w - val[d1.find(u)]));
		} else { 
			for(auto it : s[d2.find(u)]) s[d2.find(v)].insert(it);
			d2.merge(v, u); s[d2.find(v)].erase(Eid(tmp));
			while(s[d2.find(u)].size() && d1.find(e[s[d2.find(v)].begin()->x].u) == d1.find(e[s[d2.find(v)].begin()->x].v)) {
				s[d2.find(u)].erase(s[d2.find(u)].begin());
			}
			t.insert(Node(d1.find(v), e[s[d2.find(v)].begin()->x].w - val[d1.find(v)]));
		}
	}
	For(i, 1, n - 1 ) {
		printf("%lld ", ans[i]);
	}
	
    return FastIO::Fflush(), 0;
}
/*
5 8
1 2 1
1 3 6
1 4 8
1 5 7
2 3 8
3 4 3
3 5 2
4 5 6
*/



