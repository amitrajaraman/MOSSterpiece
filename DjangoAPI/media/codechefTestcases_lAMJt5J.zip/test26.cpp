#ifdef DEBUG
#define _GLIBCXX_DEBUG
#endif
//#pragma GCC optimize("O3")
#include <bits/stdc++.h>
using namespace std;
typedef long double ld;
typedef long long ll;
int n, m;
const int maxN = 2e5 + 2;
int from[maxN], to[maxN], val[maxN];
int p[maxN];
int sz[maxN];
const int maxQ = 1e6 + 228;
int SZ = 0;
int* FROM[maxQ];
int  VAL[maxQ];
void add(int& x) {
    assert(SZ < maxQ);
    FROM[SZ] = &x;
    VAL[SZ] = x;
    SZ++;
}
void del() {
    assert(SZ > 0);
    SZ--;
    *FROM[SZ] = VAL[SZ];
}
int find(int x) {
    while (p[x] != x) x = p[x];
    return x;
}
bool unite(int a, int b) {
    a = find(a);
    b = find(b);
    if (a == b) return false;
    if (sz[a] < sz[b]) swap(a, b);
    add(sz[a]);
    sz[a] += sz[b];
    add(p[b]);
    p[b] = a;
    return true;
}
void roll_back(int TO) {
    assert(SZ >= TO);
    while (SZ > TO) {
        del();
    }
}

const int maxP = 200002;
const int SHIFT = maxP + 2;
ll ans[2 * maxP + 5];
int cnt[2 * maxP + 5];
void go(int l, int r, vector<int>& ones, vector<int>& other, ll cost, int cnt_one) {
    if (l > r) return;
    int mid = (l + r) / 2;
    vector<int> good1, bad1, goodother, badother;
    int BEFORE = SZ;
    int ptr1 = 0;
    int ptrother = 0;
    int now_one = cnt_one;
    ll now_cost = cost;
    while (ptr1 < ones.size() && ptrother < other.size()) {
        if (val[ones[ptr1]] + mid < val[other[ptrother]]) {
            if (unite(from[ones[ptr1]], to[ones[ptr1]])) {
                now_one++;
                now_cost += val[ones[ptr1]];
                good1.emplace_back(ones[ptr1]);
            }
            else {
                bad1.emplace_back(ones[ptr1]);
            }
            ptr1++;
        }
        else {
            if (unite(from[other[ptrother]], to[other[ptrother]])) {
                now_cost += val[other[ptrother]];
                goodother.emplace_back(other[ptrother]);
            }
            else {
                badother.emplace_back(other[ptrother]);
            }
            ptrother++;
        }
    }
    while (ptr1 < ones.size()) {
        if (unite(from[ones[ptr1]], to[ones[ptr1]])) {
            now_one++;
            now_cost += val[ones[ptr1]];
            good1.emplace_back(ones[ptr1]);
        }
        else {
            bad1.emplace_back(ones[ptr1]);
        }
        ptr1++;
    }
    while (ptrother < other.size()) {
        if (unite(from[other[ptrother]], to[other[ptrother]])) {
            now_cost += val[other[ptrother]];
            goodother.emplace_back(other[ptrother]);
        }
        else {
            badother.emplace_back(other[ptrother]);
        }
        ptrother++;
    }


    //
    ans[mid + SHIFT] = now_cost;
    cnt[mid + SHIFT] = now_one;
    if (l == r) return;
    roll_back(BEFORE);
    //good1 sure will be added
    int cntl = cnt_one;
    ll costl = cost;
    for (auto& it : good1) {
        assert(unite(from[it], to[it]));
        costl += val[it];
        cntl++;
    }
    go(l, mid - 1, bad1, goodother, costl, cntl);
    roll_back(BEFORE);
    ll costr = cost;
    int cntr = cnt_one;
    for (auto& it : goodother) {
        assert(unite(from[it], to[it]));
        costr += val[it];
    }
    go(mid + 1, r, good1, badother, costr, cntr);
    roll_back(BEFORE);
}
ll fin[maxN];
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
//    freopen("input.txt", "r", stdin);
    cin >> n >> m;
    vector<int> one;
    vector<int> other;
    for (int i = 0; i < m; i++) {
        cin >> from[i] >> to[i] >> val[i];
        from[i]--;
        to[i]--;
        if (from[i] == 0) {
            one.emplace_back(i);
        }
        else {
            other.emplace_back(i);
        }
    }
    sort(one.begin(), one.end(), [&](int x, int y){
        return val[x] < val[y];
    });
    sort(other.begin(), other.end(), [&](int x, int y){
       return val[x] < val[y];
    });
    for (int i = 0; i < n; i++) {
        p[i] = i;
        sz[i] = 1;
    }
    go(-maxP, maxP, one, other, 0, 0);
    for (int i = -maxP; i + 1 <= maxP; i++) {
        assert(cnt[i + SHIFT] >= cnt[i + 1 + SHIFT]);
    }
    assert(cnt[-maxP + SHIFT] == n - 1);
    assert(cnt[maxP + SHIFT] == 1);
    cnt[-maxP + SHIFT - 1] = n;
    fin[n - 1] = ans[-maxP + SHIFT];
    for (int j = -maxP + 1; j <= maxP; j++) {
        if (cnt[j + SHIFT - 1] != cnt[j + SHIFT]){
            assert(abs(ans[j + SHIFT - 1] - ans[j + SHIFT]) % (cnt[j + SHIFT - 1] - cnt[j + SHIFT]) == 0);
            ll delta = (ans[j + SHIFT - 1] - ans[j + SHIFT]) / (cnt[j + SHIFT - 1] - cnt[j + SHIFT]);
            for (int r = cnt[j + SHIFT - 1] - 1; r >= cnt[j + SHIFT]; r--) {
                fin[r] = ans[j + SHIFT - 1] - delta * (cnt[j + SHIFT - 1] - r);
            }
        }
    }
    for (int i = 1; i <= n - 1; i++) {
        cout << fin[i] << " ";
    }
    return 0;
}