#include <bits/stdc++.h>

using namespace std;

#define all(v) (v).begin(), (v).end()
#define sz(v) (int)(v).size()

typedef long long ll;
typedef pair<int, int> pii;


int nxt() {
    int x;
    scanf("%d", &x);
    return x;
}

struct simple_DSU {
    int n;
    vector<int> p, h;

    simple_DSU(int _size) {
        n = _size;
        p.assign(n, 0);
        iota(all(p), 0);
        h.assign(n, 0);
    }
    int getPar(int v) {
        if (v == p[v]) return v;
        return p[v] = getPar(p[v]);
    }
    bool uniSet(int u, int v) {
        u = getPar(u);
        v = getPar(v);
        if (u == v) return false;
        if (h[u] > h[v]) swap(u, v);
        p[u] = v;
        h[v] += (h[u] == h[v]);
        return true;
    }
};


struct Edge {
    int w, u, v;

    Edge() {};
    Edge(int _u, int _v, int _w): u(_u), v(_v), w(_w) {};

    bool operator < (const Edge & e) const {
        if (w != e.w) return w < e.w;
        if (u != e.u) return u < e.u;
        return v < e.v;
    }
};

vector<Edge> edges;
set<pii> S;

struct DSU {
    int n;
    vector<int> p, a;
    vector<set<pii>> out;

    DSU(int _n, vector<int> _a) {
        n = _n;
        a = _a;
        p.assign(n, 0);
        iota(all(p), 0);
        out.assign(n, set<pii>());
    }

    int getPar(int v) {
        if (v == p[v]) return v;
        return p[v] = getPar(p[v]);
    }

    int add(int i) {
        int u = getPar(edges[i].u);
        int v = getPar(edges[i].v);
        return edges[i].w - max(a[u], a[v]);
    }
    bool check(int i, int w) {
        int u = getPar(edges[i].u);
        int v = getPar(edges[i].v);
        if (u == v) return false;
        return w == add(i);
    }
    void addEdge(int i) {
        int u = getPar(edges[i].u);
        int v = getPar(edges[i].v);
        if (sz(out[u]) > sz(out[v])) swap(u, v);
        p[u] = v;
        a[v] = min(a[v], a[u]);
        out[v].erase({edges[i].w, i});
        out[u].erase({edges[i].w, i});
        for (auto x : out[u])
            out[v].insert(x);
        out[u].clear();
        int mn = out[v].begin()->second;
        S.insert({add(mn), mn});
    }
};

int main()
{

#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
#endif // ONLINE_JUDGE


    int n, m;
    scanf("%d %d", &n, &m);
    vector<Edge> alledges;
    vector<int> a(n);
    vector<ll> ans(n - 1, 0);

    while(m--) {
        int u = nxt() - 1, v = nxt() - 1, w = nxt();
        if (u == 0) {
            a[v] = w;
            ans[0] += w;
        } else {
            alledges.push_back(Edge(u, v, w));
        }
    }
    sort(all(alledges));

    simple_DSU graph(n);
    DSU dsu(n, a);

    for (auto e : alledges) {
        if (graph.uniSet(e.u, e.v)) {
            int id = sz(edges);
            S.insert({e.w - max(a[e.u], a[e.v]), id});
            dsu.out[e.u].insert({e.w, id});
            dsu.out[e.v].insert({e.w, id});
            edges.push_back(e);
        }
    }

    for (int it = 1; it < n - 1; ++it) {
        while(true) {
            int i = S.begin()->second;
            int add = S.begin()->first;
            S.erase(S.begin());
            if (!dsu.check(i, add)) {
            	S.insert({dsu.add(i), i});
            	continue;
            } 
            dsu.addEdge(i);
            ans[it] = ans[it - 1] + add;
            break;
        }
    }

    reverse(all(ans));
    for (int i = 0; i < n - 1; ++i)
        printf("%lld ", ans[i]);



}
