/*********** [ scopeInfinity ] ******************/
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <map>
#include <set>
#include <queue>
#include <unordered_map>
#include <cmath>
#include <sstream>
#include <bitset>
#include <cassert>
#include <climits>

using namespace std;

#ifdef linux
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
template <class T>
using ost = tree< T, null_type, less<T>, rb_tree_tag,
  tree_order_statistics_node_update>;
// *find_by_order, order_of_key
typedef gp_hash_table<int, int, hash<int> > hash_table;
#endif

#ifndef LOCAL
const int ISLOCAL = 1;
int INPUT = 0;
#else
const int ISLOCAL = 0;
int INPUT = 1;
#endif

typedef long long ll;
typedef long double ld;
typedef std::vector<ll> vll;
typedef std::vector<pair<int,int> > vpi;
typedef std::vector<pair<ll,ll> > vpl;
typedef std::vector<int> vi;

ll MOD = 998244353;
ll PRIME =  999727999;
ll PRIME2 = 999999937;
ll INF = LLONG_MAX/4;

#define forv(it,m) for (auto it = (m).begin(); it != (m).end(); ++it)
#define rep(i,n) for (int i=0;i<(int)(n);i++)
#define repr(i,n) for (int i=(int)(n)-1;i>=0;i--)
#define all(v) v.begin(),v.end()
#define endl '\n'
#define mp make_pair
#define pb(x) push_back((x))
#define what_is(x) cerr << #x << " is " << (x) << endl;
#define NEW(x,n) {(x).clear();(x).resize((n));}
#define xx first
#define yy second

template <class F1,class F2> ostream& operator<<(ostream& os, const pair<F1,F2>& p) {
  return os<<p.xx<<' '<<p.yy; }
template <class F1,class F2> istream& operator>>(istream& is, pair<F1,F2>& p) {
  return is>>p.xx>>p.yy; }
template <class F> ostream& operator<<(ostream& os, const std::vector<F>& v) {
  rep(i,v.size()) os<<v[i]<<" "; return os; }
template <class F> istream& operator>>(istream& is, std::vector<F> &v) {
  rep(i,v.size()) is>>v[i];  return is;  }

vector<string> split(const std::string &s, char delim) {
    vector<string> e; stringstream ss(s);string item;
    while(getline(ss, item, delim)) e.push_back(item);
    return e;
}

ll Pow(ll a ,ll b ,ll Mo){
    ll ans = 1;
    for (; b; b >>= 1, a = a * a % Mo) if (b&1) ans = ans * a % Mo;
    return ans;
}
ll inv(ll a) { return Pow(a,MOD-2,MOD); }
ll nCr(ll n,ll r) {
    static ll MAXF = 1e6;static std::vector<ll> fact(MAXF,1);
    for (int i = 1; i < MAXF; ++i)  fact[i]=(fact[i-1]*i)%MOD;
    MAXF=0; return (fact[n]*Pow((fact[r]*fact[n-r])%MOD,MOD-2,MOD))%MOD;
}

ll solve() {
  int x;
  cin>>x;
  return x;
}

class DSU{
public:
    std::vector<int> par;
    DSU(int n) {
        par=std::vector<int>(n,-1);
    }

    int root(int v){
        if(par[v]<0)
            return v;
        return (par[v] = root(par[v]));
    }

    int merge(int x,int y){ 
      // returns final root
        if((x = root(x)) == (y = root(y)) )
            return x;
        if(par[y] < par[x])
            swap(x, y);
        par[x] += par[y];
        par[y] = x;
	return x;
    }
};

vector<vector<int> > G;

int main(int argc, char const *argv[])
{
    std::ios::sync_with_stdio(false);cin.tie(0);
    // cout<<fixed<<setprecision(1);
    if(ISLOCAL) srand(100);  else  srand(time(NULL));

    int n,m;
    cin>>n>>m;
    G.resize(n);
    vector<pair<ll, pair<int,int> > > edges;
    DSU dsu(n);
    rep(i,m) {
      int u,v;
      ll x;
      cin>>u>>v>>x;
      u--;v--;
      if(u>v) swap(u,v);
      edges.push_back(mp(x,mp(u,v)));
    }
    sort(all(edges));
    vector<ll> root_i_weight(n,INF);
    // clustor_i outoing edges <weight, o_node>
    vector<set<pair<ll,int> > > clustor_out(n);
    for(auto e:edges) {
      ll w = e.xx;
      int u = e.yy.xx;
      int v = e.yy.yy;
      if(u!=0) {
	if(dsu.root(u) != dsu.root(v)) {
	  dsu.merge(u,v);
	  G[u].push_back(v);
	  G[v].push_back(u);
	  clustor_out[u].insert(mp(w, v));
	  clustor_out[v].insert(mp(w, u));
	}
      } else {
	// edges to root
	root_i_weight[v] = w;
      }
    }
    
    //  rep(i,n) {
    //   sort(all(clustor_out[i])); 
    //   reverse(all(clustor_out[i])); 
    // }
    priority_queue<pair<ll, pair<int,int> > > pq;
    
    rep(i, n) if(i>0) {
      assert(clustor_out[i].size()>0);
      auto it = clustor_out[i].begin();
      ll c = it->xx - root_i_weight[i];
      int o = it->yy;
      pq.push({-c, {i,o}});
      // cout<<"Push "<<(c)<<" for "<<(i+1)<<"->"<<(o+1)<<endl;
    }
    
    

    vector<ll> ans(n-1);

    ll cost = 0;
    {
      // 1->(n-1) nodes are connected to root.
      rep(i, n-1) {
	cost += root_i_weight[i+1];
      }
      ans[n-2] = cost;
    }
    DSU yo(n);
    vector<int> clustors(n);
    // cout<<cost_of_merge<<": "<<cost<<endl;
    vector<int> marked(n, 0);

    vector<int> valid_clustor(n, 1);
    rep(z, n-2) {
      int FOUND = 0;
      while(!FOUND) {
	auto pp = pq.top();
	pq.pop();
	// cout<<"Pop "<<(-pp.xx)<<" a:"<<(pp.yy.xx+1)<<" b:"<<(pp.yy.yy+1)<<endl;
	int a = pp.yy.xx;
	int b = pp.yy.yy;
	ll diff = -pp.xx;
	if(!valid_clustor[a]) continue;
	// assert(clustor_out[a].size() > 0 );
	if(clustor_out[a].size()>0)
	{
	  auto it = clustor_out[a].begin();
	  // if(diff < it->xx - root_i_weight[a]) {
	  // // stale entry in queue.
	  // continue;
	  //}
	  if((it->xx == diff + root_i_weight[a]) && (it->yy == b)) {
	    
	  } else {
	    // forcing assert to be true and ignoring stale entries.
	    continue;
	  }
	  assert(it->xx == diff + root_i_weight[a]);
	  assert(it->yy == b);
	  
	  clustor_out[a].erase(it);
	}
	if(yo.root(a) != yo.root(b)) {
	  assert(a == yo.root(a));
	  b = yo.root(b);
	  cost += diff;  
	  // cout<<"Added "<<(a+1)<<"->"<<(b+1)<<"\n";
	  // cout<<"Removed 1->"<<(a+1)<<endl;
	  // cout<<" diff: "<<diff<<" Cost: "<<cost<<endl;
	  //  removed root -> i edge and add a internal edge
	  // to keep 1->(n-1) nodes connected via MST.
	  ans[n-3-z] = cost;
	  int other_root_i_weight = root_i_weight[b];
	  int kr = yo.merge(a,b); // returned value ignored for now.
	  int ko;
	  if(kr==a) ko = b; else ko = a;
	  a=kr; // new root
	  b=ko;
	  valid_clustor[b] = 0;
	  root_i_weight[a] = other_root_i_weight;
	  for(auto x:  clustor_out[b]) {
	    // cout<<"  Moved "<<x<<" from "<<(ko+1)<<" to "<<(kr+1)<<endl;
	    clustor_out[a].insert(x);
	  }
	  clustor_out[b].clear();
	  FOUND = 1;
	}
	if(clustor_out[a].size()>0) {
	  auto it = clustor_out[a].begin();
	  ll c = it->xx - root_i_weight[a];
	  int o = it->yy;
	  // cout<<"Push "<<(c)<<" for "<<(kr+1)<<"->"<<(o+1)<<endl;
	  pq.push({-c, {a, o}});
	}
      }
    }
    
    cout<<ans<<endl;
    return 0;
}
