#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <queue>
using namespace std;

#define FOR(i,n) for (int i = 0; i < (n); i++)

struct Edge {
  int a,b,w,lamb;
};

int n, ne;
Edge e[333333];

int uf[222222];
int rootwt[222222];
int find(int x) { return uf[x] == -1 ? x : (uf[x] = find(uf[x])); }
void unite(int a, int b) { a=find(a); b = find(b); if (a-b) uf[a]=b; }

long long ans[222222];

int main() {
  scanf("%i%i", &n, &ne);
  FOR(i,ne) scanf("%i%i%i", &e[i].a, &e[i].b, &e[i].w), e[i].a--, e[i].b--;

  sort(e,e+ne, [](const Edge &a, const Edge &b) { return a.w < b.w; });

  FOR(i,ne) if (!e[i].a) rootwt[e[i].b] = e[i].w;
  FOR(i,ne) if (!e[i].b) rootwt[e[i].a] = e[i].w;
  memset(uf,-1,sizeof(uf));

  vector<Edge> tree, bush;
  FOR(i,ne) {
    if (e[i].a && e[i].b) {
      int a = find(e[i].a), b = find(e[i].b);
      if (a-b) {
        e[i].lamb = e[i].w - max(rootwt[a], rootwt[b]);
        uf[a] = b;
        rootwt[b] = min(rootwt[a], rootwt[b]);
        tree.push_back(e[i]);
      }
    } else bush.push_back(e[i]);
  }
  sort(tree.begin(), tree.end(), [](const Edge &a, const Edge &b) { return a.lamb > b.lamb; });
  long long treewt = rootwt[find(1)];
  for (auto e : tree) treewt += e.w;
  int k = 0;
  ans[k++] = treewt;
  for (auto e : tree) ans[k++] = (treewt -= e.lamb);
  FOR(i,k) printf(i?" %lli":"%lli", ans[i]); printf("\n");
}
