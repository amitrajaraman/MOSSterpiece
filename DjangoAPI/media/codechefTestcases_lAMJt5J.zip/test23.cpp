//clear adj and visited vector declared globally after each test case
//check for long long overflow
//while adding and subs check if mod becomes -ve
//while using an integer directly in a builtin function add ll
//Mod wale question mein last mein if dalo ie. Ans<0 then ans+=mod;
//Dont keep array name as size or any other key word
#pragma GCC optimize("Ofast")  
#pragma GCC target("avx,avx2,fma") 
#include <bits/stdc++.h> 
#include <ext/pb_ds/assoc_container.hpp>
#define int long long
#define IOS std::ios::sync_with_stdio(false); cin.tie(NULL);cout.tie(NULL);cout.precision(dbl::max_digits10);
#define pb push_back
#define mod 1000000007ll //998244353ll
#define lld long double
#define mii map<int, int>
#define mci map<char, int>
#define msi map<string, int>
#define pii pair<int, int>
#define ff first
#define ss second 
#define all(x) (x).begin(), (x).end()
#define rep(i,x,y) for(int i=x; i<y; i++)    
#define fill(a,b) memset(a, b, sizeof(a))
#define vi vector<int>
#define setbits(x) __builtin_popcountll(x)
#define print2d(dp,n,m) for(int i=0;i<=n;i++){for(int j=0;j<=m;j++)cout<<dp[i][j]<<" ";cout<<"\n";}
typedef std::numeric_limits< double > dbl;
using namespace __gnu_pbds;
using namespace std;
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> indexed_set;
const int N=200005;// INF=2000000000000000000;
lld pi=3.1415926535897932;
int lcm(int a, int b)
{
    int g=__gcd(a, b);
    return a/g*b;
}
int power(int a, int b, int p)
    {
        if(a==0)
        return 0;
        int res=1;
        a%=p;
        while(b>0)
        {
            if(b&1)
            res=(res*a)%p;
            b>>=1;
            a=(a*a)%p;
        }
        return res;
    }
set <pair <int, pii> > s[N];
int par[N], dist[N], cur[N];
int32_t main()
{
    IOS;
    int n, m;
    cin>>n>>m;
    vector <pii> temp;
    for(int i=0;i<m;i++)
    {
        int a, b, w;
        cin>>a>>b>>w;
        if(b<a)
        swap(a, b);
        if(a==1)
        {
            temp.pb({b, w});
            dist[b]=w;
            par[b]=b;
        }
        else
        {
            s[a].insert({w, {a, b}});
            s[b].insert({w, {b, a}});
        }
    }
    int ans=0;
    set <pii> sm;
    for(auto p:temp)
    {
        ans+=p.ss;
        cur[p.ff]=(*s[p.ff].begin()).ff-p.ss;
        sm.insert({cur[p.ff], (*s[p.ff].begin()).ss.ff});
    }
    vi fans;
    fans.pb(ans);
    //cout<<sm.size()<<"\n";
    while(((int)sm.size())>1)
    {
        pair <int, int> p=(*sm.begin());
        sm.erase(p);
        ans+=p.ff;
        int a=p.ss;
        int b=(*s[a].begin()).ss.ss;
        while(b!=par[b])
        b=par[b];
        sm.erase({cur[b], b});
        int nd=dist[b];
        if(s[a].size()>s[b].size())
        swap(a, b);
        for(auto it:s[a])
        {
            if(s[b].find({it.ff, {it.ss.ss, it.ss.ff}})!=s[b].end())
            s[b].erase({it.ff, {it.ss.ss, it.ss.ff}});
            else
            s[b].insert({it.ff, {it.ss.ff, it.ss.ss}});
            par[it.ss.ff]=b;
        }
        cur[b]=(*s[b].begin()).ff-nd;
        dist[b]=nd;
        par[a]=b;
        sm.insert({cur[b], b});
        //cout<<sm.size()<<" "<<ans<<"\n";
        fans.pb(ans);
    }
    reverse(all(fans));
    for(auto num:fans)
    cout<<num<<" ";
}
