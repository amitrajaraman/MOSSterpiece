#include <bits/stdc++.h>
using namespace std;

using ll = long long;

namespace std {

template<class Fun>
class y_combinator_result {
	Fun fun_;
public:
	template<class T>
	explicit y_combinator_result(T &&fun): fun_(std::forward<T>(fun)) {}

	template<class ...Args>
	decltype(auto) operator()(Args &&...args) {
		return fun_(std::ref(*this), std::forward<Args>(args)...);
	}
};

template<class Fun>
decltype(auto) y_combinator(Fun &&fun) {
	return y_combinator_result<std::decay_t<Fun>>(std::forward<Fun>(fun));
}

} // namespace std

struct UF {
    int n;
    vector<int> par;
    UF(int _n) : n(_n) {
        for(int i = 0; i < n; i++) par.push_back(i);
    }
    int find(int a){
        if(a != par[a]) par[a] = find(par[a]);
        return par[a];
    }
    bool join(int a, int b){
        a = find(a);
        b = find(b);
        par[a] = b;
        return (a != b);
    }
};

int main(){
	ios_base::sync_with_stdio(false), cin.tie(nullptr);
	int n, m;
	cin >> n >> m;
	n--;
	vector<int> val(n);
	vector<pair<int, pair<int,int> > > all_edges;
	for(int i = 0; i < m; i++){
		int u, v, w;
		cin >> u >> v >> w;
		u -= 2; v -= 2;
		if(u > v) swap(u, v);
		if(u == -1){
			val[v] = w;
		} else {
			all_edges.push_back({w, {u, v}});
		}
	}
	sort(all_edges.begin(), all_edges.end());
	UF uf(n);
	vector<set<pair<int,int> > > neighbor_edges(n);
	for(int i = 0; i < (int)all_edges.size(); i++){
		int v = all_edges[i].second.first;
		int w = all_edges[i].second.second;
		if(uf.join(v, w)){
			neighbor_edges[v].insert({all_edges[i].first, i});
			neighbor_edges[w].insert({all_edges[i].first, i});
		}
	}
	vector<int> par(n);
	for(int i = 0; i < n; i++) par[i] = i;
	auto find = y_combinator(
		[&](auto self, int a) -> int {
			if(a != par[a]) par[a] = self(par[a]);
			return par[a];
		}
	);
	ll tot_score = 0;
	for(int i = 0; i < n; i++) tot_score += val[i];
	vector<ll> ans(n);
	ans[0] = tot_score;
	vector<int> vertex_cost = val;
	set<pair<int,int> > costs;
	for(int j = 0; j < n; j++){
		if(neighbor_edges[j].empty()) continue;
		costs.insert({(*neighbor_edges[j].begin()).first - vertex_cost[j], j});
	}
	for(int i = 1; i < n; i++){
		int best_score = 1e9;
		int idx = -1;
		tie(best_score, idx) = *costs.begin();
		tot_score += best_score;
		ans[i] = tot_score;
		int id = (*neighbor_edges[idx].begin()).second;
		int v = all_edges[id].second.first;
		int w = all_edges[id].second.second;
		v = find(v);
		w = find(w);
		assert(idx == v || idx == w);

		costs.erase({(*neighbor_edges[v].begin()).first - vertex_cost[v], v});
		costs.erase({(*neighbor_edges[w].begin()).first - vertex_cost[w], w});
		int new_cost = vertex_cost[v] + vertex_cost[w] - vertex_cost[idx];
		neighbor_edges[v].erase({all_edges[id].first, id});
		neighbor_edges[w].erase({all_edges[id].first, id});
		if(neighbor_edges[v].size() < neighbor_edges[w].size()){
			swap(v, w);
		}
		for(auto x : neighbor_edges[w]) neighbor_edges[v].insert(x);
		neighbor_edges[w].clear();
		vertex_cost[v] = new_cost;
		par[w] = v;
		costs.insert({(*neighbor_edges[v].begin()).first - vertex_cost[v], v});
	}
	reverse(ans.begin(), ans.end());
	for(ll x : ans) cout << x << ' ';
	cout << '\n';
}