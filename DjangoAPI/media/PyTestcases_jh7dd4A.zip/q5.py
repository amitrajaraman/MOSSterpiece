def rotate(m):
    #rotates m where m is a list of lists of integers
    n=len(m)
    r=[]
    temp=[]
    for i in range(n):
        for j in range(n):
            temp.append(m[n-1-j][i])
        r.append(temp)
        temp=[]
    return r
#taking input, assuming first line as n numbers, following n-1 lines also has n numbers each
m=[]
str_line=input()
line=str_line.split(' ')
n=len(line)
temp=[]
for i in range(n):
   temp.append(int(line[i]))
m.append(temp)    
temp=[]
for i in range(n-1):
   str_line=input()
   line=str_line.split(' ')
   for i in range(n):
       temp.append(int(line[i]))
   m.append(temp)
   temp=[]
# after rotating, printing the rotated matrix to stdout
r=rotate(m)
for i in r:
   print(str(i)[1:-1].replace(',',''))
