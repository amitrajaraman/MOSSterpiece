def rotate(m):
	rot_m = []
	length = len(m)
	for i in range(length):
		for j in range(length):
			if(i==0):
				rot_m.append([ m[length-1-i][j] ])
			else:
				rot_m[j].append(m[length-1-i][j])
	return rot_m