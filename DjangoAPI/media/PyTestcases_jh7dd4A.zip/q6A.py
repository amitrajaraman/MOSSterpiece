from functools import reduce
def collapse(L):
	if isinstance(L, list):
		L = reduce(lambda a,b: collapse(a) + " " + collapse(b),L)
	return L