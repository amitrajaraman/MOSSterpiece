from ring import *
from functools import reduce

# x^i / i!

class Series:

	def __init__(self, k, x, n):
		self.modulus = int(n)
		self.value = RingInt(n,1)
		self.mult = RingInt(n,x)
		self.max = int(k)
		self.index = 0

	def __iter__(self):
		self.value = RingInt(self.modulus,1)
		self.index = 0
		return self

	def __next__(self):
		def _factorial(n):
			if(n == 0):
				return 1
			else:
				return reduce(lambda a,b: a*b, range(1,n+1))
		try:
			if(self.index >= self.max):
				raise StopIteration
			self.value = (self.mult ** self.index) / RingInt(self.modulus, _factorial(self.index))
			self.index = self.index + 1
		except ValueError:
			print("UNDEFINED")
			raise StopIteration
		return self

	def __str__(self):
		return str(self.value)

def main():

	in_str = str(input())
	in_list = in_str.split(' ')
	k, x, n = in_list[0], in_list[1], in_list[2]

	for ele in Series(k, x, n):
		print(ele)

if __name__=="__main__":
	main()