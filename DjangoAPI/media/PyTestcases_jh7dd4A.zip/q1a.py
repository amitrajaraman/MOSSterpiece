from ring import *
import argparse

# This code uses argparse which compels the user to give input and output files
parser = argparse.ArgumentParser()
parser.add_argument('-in', dest='input', help='The path to input file', type=str, required=True)
parser.add_argument('-out', dest='output', help='The path to input file', type=str, required=True)
args = parser.parse_args()

def series1(k,x,n):
	sum = RingInt(0, n)
	num = RingInt(x,n)
	fac = RingInt(1, n)
	# calculates series through for loop
	for i in range(0,k):
		if(i!=0):
			fac*=RingInt(i, n)
		sum+= num**i/fac
	return str(sum)+"\n"

def series2(k,x,n):
	def factorial(r,n):
		if(r==0):
			return RingInt(1,n)
		else:
			return RingInt(r,n)*factorial(r-1,n)
	# Higher order function to calculate nCr
	def c(k,r,n):
		mult = factorial(k-r,n)*factorial(r,n)
		c = factorial(k,n)/mult
		return c
	#for loops calculates series
	prod = RingInt(1,n)
	for i in range(0,k):
		sum = RingInt(0, n)
		for j in range(0,i+1):
			sum+=c(x+i,j,n)
		prod*=sum
	return str(prod)+"\n"

def series3(k,x,n):
	# for loop calculates series
	sum = RingInt(0,n)
	x = RingInt(0,n)
	for k in range(1,line[0]+1):
		x.value = k
		sum += x**line[1]
	return str(sum)+"\n"
	
s=""
f = open(args.input)	
for line in f:
	# k x n i
	line = line.split()
	line = list(map(lambda x: int(x),line))
	try:
		n = line[2]
		k = line[0]
		x = line[1]
		# call functions based on input
		# add undefined if a value error is encountered
		if(line[3]==1):
			try:
				s+=series1(k, x, n)
			except Exception as e:
				s+="UNDEFINED\n"
		elif(line[3]==2):
			try:
				s+=series2(k, x, n)
			except Exception as e:
				s+="UNDEFINED\n"
		elif(line[3]==3):
			try:
				s+=series3(k, x, n)
			except Exception as e:
				s+="UNDEFINED\n"
	except:
		break			
		
output = open(args.output,'w')
output.write(s)
