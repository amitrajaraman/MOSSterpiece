from collections import defaultdict as dd
import argparse

def add_cust(c_type, price, cust):
	if(cust[c_type] == 0):
		_tmp = []
		_tmp.append(price)
		cust[c_type] = _tmp
		return
	else:
		for i in range(len(cust[c_type])):
			if(price > cust[c_type][i]):
				cust[c_type].insert(i, price)
				return
		cust[c_type].append(price)

parser = argparse.ArgumentParser(usage="python3 q1b.py -in <input-file> -out <output-file>")
parser.add_argument("-ca", "--candies", required=True)
parser.add_argument("-ch", "--children", required=True)
args = parser.parse_args()

cand_file = args.candies
child_file = args.children
cand_file = open(cand_file, "r")
child_file = open(child_file, "r")

num_candy = cand_file.readline().strip()
candy_types = cand_file.readline().strip().split(" ")
candy_needed = []
in_stock = dd(int)
cust = dd(int)

for candy_type in candy_types:
	in_stock[int(candy_type)]+=1  #dd(int) returns 0 by default if no key is present

num_children = int(child_file.readline().strip())

for i in range(num_children):
	_data = child_file.readline().strip().split(" ")
	add_cust(int(_data[0]), int(_data[1]), cust)
	candy_needed.append(int(_data[0]))

income = 0

for c_type in candy_needed:
	if in_stock[c_type] != 0:
		in_stock[c_type] = in_stock[c_type]-1
		income += cust[c_type][0]
		cust[c_type].pop(0)

print(income)