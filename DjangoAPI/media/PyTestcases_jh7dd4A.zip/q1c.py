from ring import *

class Series:
	def __init__(self,k,x,n):
		self.n = int(n)
		self.k = int(k)
		self.x = RingInt(int(x), self.n)
	# the iter function initialises the iterator at the start of iteration
	def __iter__(self):
		self.i = 0
		self.term = RingInt(1, self.n)
		self.undefined = False
		return self
	# the next function gives next element in the series
	def __next__(self):
		if self.i < self.k:
			# return 1 for 1st element
			if(self.i==0):
				self.i += 1
				return RingInt(1, self.n)
			# return x^i/i! for the following terms
			# if one undefined term is encountered, the following terms will also be undefined
			try:
				self.i += 1
				if self.undefined:
					raise ValueError
				self.term = (self.x*self.term)/RingInt(self.i-1,self.n)
			except Exception as e: 
				self.undefined = True
				raise StopIteration
			return self.term
		else:
			raise StopIteration
			# return "MAX k value reached"
		

def main():
	in_str = str(input())
	in_list = in_str.split(' ')
	k, x, n = in_list[0], in_list[1], in_list[2]
	for ele in Series(k, x, n):
		print(ele)


if __name__=="__main__":
	main()
