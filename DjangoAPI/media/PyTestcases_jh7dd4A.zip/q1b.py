from ring import *
import argparse
#parsing
parser = argparse.ArgumentParser()
parser.add_argument('-m', dest='input', help='The path to input file', type=str, required=True)
args = parser.parse_args()

def check(s,i):
    #s is the string, gonna check if s is of the form $(......)#(..........)$
    if(s[i] != '$'): return -1
    try:
        dollar = (s[i+1:].index('$') + i+1) 
    except:
        return -1 
    if(s[i+1] != '('): return -1
    if(s[dollar-1] != ')'): return -1
    try:
        h = (s[i:dollar]).index('#') + i 
    except:
        return -1
    if(s[h-1] != ')'): return -1
    if(s[h+1] != '('): return -1
    for x in s[i+1:dollar]:
        if(not x.isnumeric() and x not in ',()#'):
            return -1
    
    # Checks if there are appropriate no of commas
    if(2*s[i+2:h-1].count(',')+1!=len(s[i+2:h-1])): return -1
    if(2*s[h+2:dollar-1].count(',')+1!=len(s[h+2:dollar-1])): return -1
    # Checks if all are numbers
    code = s[i+2:h-1].replace(',', '') + s[h+2:dollar-1].replace(',', '')
    for x in code:
        if(not x.isnumeric()):
            return -1
    return dollar
#checking if the code is corrupted
def checkcode(s,start,end,n):
    a=[]
    b=[]
    for x in s[start+1:end]:
        if(x.isnumeric()):
            if(int(x)>=n):
                return False
            b.append(RingInt(int(x),n))
        elif(x == ')'):
            a.append(b)
            b=[]    
    #return a
    sum1=RingInt(0,n)
    sum2=RingInt(0,n)
    if(len(a)==2):
        for i in range(len(a[0])):
            sum1 += RingInt((i+1)%n,n)*a[0][i]
        for j in range(len(a[1])):
            sum2 += RingInt((j+1)%n,n)*a[1][j]
        if(sum1.value ==0 and sum2.value == 0):
            return True
        else:
            return False            
    else:
        print('Im here')
        return True
#checking all the codes, if they are corrupted. returning corrupted even if one code is corrupted.
num=0
c=True
with open(args.input) as f:
    num=int(f.readline())
    s=(f.read())
    for i in range(len(s)):
        test = check(s, i)
        if(test!=-1):
            c = c and checkcode(s,i,test,num)

if(c):
    print("OK")
else:
    print("CORRUPTED")    
    