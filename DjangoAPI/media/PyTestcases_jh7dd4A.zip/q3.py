from collections import defaultdict
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('-ca', dest='candies', help='The path to candies.txt file', type=str, required=True)
parser.add_argument('-ch', dest='children', help='The path to children.txt file', type=str, required=True)
args = parser.parse_args()

candiesfile = args.candies
childrenfile = args.children

def maxamount(n,list):
    list.sort(reverse=True)
    sum=0
    for i in range(min(len(list),n)):
        sum = sum + list[i]
    return sum    


#default dict to store the number of candies of that type 
num=defaultdict(int)

with open(candiesfile) as ca:
    line=ca.readline()
    n=int(line)
    line=ca.readline().split()
    for i in line:
        num[int(i)] +=1

#default dict to store the amount that people will pay 
amount=defaultdict(list)
with open(childrenfile) as ch:
    line=ch.readline()
    for i in range(int(line)):
        line=ch.readline()
        l = line.split()
        amount[int(l[0])].append(int(l[1]))

sum=0
for key,value in num.items():
    sum += maxamount(value,amount[key])

print(sum)