from ring import *
import argparse

parser = argparse.ArgumentParser(usage="python3 q1b.py -in <input-file> -out <output-file>")
parser.add_argument("-in", "--input", required=True)
parser.add_argument("-out", "--output", required=True)
args = parser.parse_args()
infile = args.input
outfile = args.output
infile = open(infile).read()
outfile = open(outfile, "w")

def expapprox(k, x, n):
	temp = RingInt(n,1)
	res = RingInt(n,1)
	for i in range(1,k):
		try:
			temp = temp * RingInt(n,x)
			temp = temp / RingInt(n,i)
			res = res + temp
		except ValueError:
			return "UNDEFINED"
	return res
	
def binom(k, x, n):
	res = RingInt(n,1)
	def factorial(inp):
		if(inp == 0):
			return 1
		res = 1
		for counter in range(1, inp+1):
			res = (res*counter) % n
		return res
	for i in range(0,k):
		currSum = RingInt(n,0)
		try:
			tempList = [(RingInt(n, factorial(x+i)) / (RingInt(n, factorial(j)) * RingInt(n, factorial(x+i-j)))) for j in range(0, i+1)]
			for elem in tempList:
				currSum = currSum + elem
		except ValueError:
			return "UNDEFINED"
		res = res * currSum
	return res

def powsum(k, x, n):
	res = RingInt(n,0)
	for i in range(1,k+1):
		try:
			res = res + (RingInt(n,i) ** x)
		except ValueError:
			return "UNDEFINED"
	return res

for line in infile.split("\n"):
	parameters = [int(i) for i in line.split()]
	if len(parameters) == 4:
		if(parameters[3] == 1):
			outfile.write(str(expapprox(parameters[0], parameters[1], parameters[2])))
			#print(str(expapprox(parameters[0], parameters[1], parameters[2])))
		elif(parameters[3] == 2):
			outfile.write(str(binom(parameters[0], parameters[1], parameters[2])))
			#print(str(binom(parameters[0], parameters[1], parameters[2])))
		elif(parameters[3] == 3):
			outfile.write(str(powsum(parameters[0], parameters[1], parameters[2])))
			#print(str(powsum(parameters[0], parameters[1], parameters[2])))
		outfile.write("\n")