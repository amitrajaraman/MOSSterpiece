from itertools import product

class Node(object):
	"""
	Node contains two objects - a left and a right child, both may be a Node or both None,
	latter representing a leaf
	"""
	def __init__(self, left=None, right=None):
		super(Node, self).__init__()
		self.left = left
		self.right = right

	def __str__(self):
		"""
		Default inorder print
		"""
		if self.left is None and self.right is None:
			return "(   )"
		else:
			return "( " + str(self.left) + " " + str(self.right) + " )"

	def __eq__(self, other):
		if self.left is None and self.right is None:
			return other.left is None and other.right is None
		elif self.left is None and self.right is None:
			return False
		else:
			return self.left == other.left and self.right == other.right


def mirrorTree(node):
	"""
	Returns the mirror image of the tree rooted at node
	"""
	node.left, node.right=node.right, node.left
	if isinstance(node.left,Node):
		node.left = mirrorTree(node.left)
	if isinstance(node.right,Node):
		node.right = mirrorTree(node.right)
	return node


def allTrees(n):
	"""
	Returns a list of all unique trees with n internal nodes
	"""
	if(n==0): return [Node()]
	if(n==1): return [Node(Node(),Node())]
	sum = []
	for i in range(0,n):
		l = list(map(lambda x: Node(x[0],x[1]),list(product(allTrees(i),allTrees(n-i-1)))))
		sum+=l
	return sum

def allSymTrees(n):
	"""
	Returns a list of all unique symmetrical trees with n internal nodes
	"""
	if n%2==0: return []
	l = list(map(lambda x: Node(x,x),allTrees(int((n-1)/2)) ))
	return l

if name == 'main':
	for x in allSymTrees(int(input())):
		print(x)
	node = Node(Node(Node(), Node()), Node())
	print(node)
