import argparse
from ring import *
import re
from functools import *

parser = argparse.ArgumentParser(usage="python3 q1b.py -m <message_file>")
parser.add_argument("-m", "--message", required=True)
args = parser.parse_args()
infile = args.message
infile = open(infile).read()

modulus = int(infile[0])

l = [string.group() for string in re.finditer("\$\(([0-9]+,)*[0-9]+\)\#\(([0-9]+,)*[0-9]+\)\$", infile)]
#gets each string of the desired form
l = [s[1:-1].split("#") for s in l]
#strips the two $s and splits it into two based on #
l = [[s[1:-1].split(",") for s in elem] for elem in l]
#strips the parentheses and splits it based on the commas
flag = any([any([any([(int(c) >= modulus) for c in s]) for s in elem]) for elem in l])
if(flag):
	print("CORRUPTED")
else:
	l = [[[RingInt(modulus, (ind+1)*int(c)) for ind, c in enumerate(s)] for s in elem] for elem in l]
	#converts each element from a string to a RingInt
	l = [[(reduce(lambda a,b:a+b, s)).value for s in elem] for elem in l]
	#adds all the elements in each subsublist
	l = any([any(elem) for elem in l])
	#since 0 is detected as false, this checks if anything is True in the entire list of lists (which implies CORRUPTED)
	if(l):
		print("CORRUPTED")
	else:
		print("OK")	