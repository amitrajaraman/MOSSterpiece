import argparse
#parsing 
parser = argparse.ArgumentParser()
parser.add_argument('-in', dest='input', help='The path to input file', type=str, required=True)
parser.add_argument('-out', dest='output', help='The path to input file', type=str, required=True)
args = parser.parse_args()

inputfile = args.input
outputfile = args.output
f=open(inputfile,'r')
inpath=f.readline()
f.close()

#checking if its a valid path
error = list(filter(lambda x: not (x.isalnum() or x in '/_-.\n'),inpath))
if len(error):
	print('Invalid Path')
	exit(1)

l=[]
s=''
#making a list of directory and file names
count=0
for i in inpath:
    if i=='/' or i=='\n':
    	if s=='.':
    		pass
    	elif s=='..':
    		try:
    			del l[-1]
    		except:
    			pass
    	elif s!='':
    		l.append(s)
    	s=''
    else:
        s+=i 
path=''
#writing them out as a path
if(len(l)>0):
    for i in l:
	        path += '/' + i     
else:
    path= '/'   

fi=open(outputfile,'w')
fi.write(path)
fi.close() 