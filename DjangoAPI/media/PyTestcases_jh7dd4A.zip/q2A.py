import argparse

parser = argparse.ArgumentParser(usage="python3 q1b.py -in <input-file> -out <output-file>")
parser.add_argument("-in", "--input", required=True)
parser.add_argument("-out", "--output", required=True)
args = parser.parse_args()
source_file = args.input
dest_file = args.output
source_file = open(source_file)
dest_file = open(dest_file, "w")


orig_path = source_file.read().strip()
dirs = orig_path.split('/')
output = ""
res_dirs = []

for indiv_dir in dirs:
	if indiv_dir == '..':
		if len(res_dirs) != 0:
			res_dirs.pop()
	elif indiv_dir != '' and indiv_dir != '.':
		res_dirs.append(indiv_dir)

if(len(res_dirs) == 0):
	output = "/"

for i in res_dirs:
	output += "/" + i

dest_file.write(output)
source_file.close()
dest_file.close()