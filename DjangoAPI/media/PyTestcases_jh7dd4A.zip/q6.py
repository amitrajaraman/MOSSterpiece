from functools import reduce

def collapse(L):
    #the function below removes all the nesting and flattens out the list
    #the [] initialiser ensures there is no error even if empty list is passed
    c = lambda lis: reduce(lambda a,b: a + b , map(c,lis),[]) if isinstance(lis,list) else [lis]
    #joining all the strings inside c(L) with a space separator
    s=" ".join(c(L))
    return s

L = [ ["this","is"], [ ["an", "interesting", "python"], ["programming", "exercise."] ] ] 
print(collapse(L))