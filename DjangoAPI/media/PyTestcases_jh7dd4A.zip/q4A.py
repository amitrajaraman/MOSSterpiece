class Node(object):
	"""
	Node contains two objects - a left and a right child, both may be a Node or both None,
	latter representing a leaf
	"""
	def __init__(self, left=None, right=None):
		super(Node, self).__init__()
		self.left = left
		self.right = right

	def __str__(self):
		"""
		Default inorder print
		"""
		if self.left is None and self.right is None:
			return "(   )"
		else:
			return "( " + str(self.left) + " " + str(self.right) + " )"

	def __eq__(self, other):
		if self.left is None and self.right is None:
			return other.left is None and other.right is None
		elif other.left is None and other.right is None:
			return False
		else:
			return self.left == other.left and self.right == other.right


def mirrorTree(node):
	"""
	Returns the mirror image of the tree rooted at node
	"""
	if node is None:
		return node
	else:
		mir = Node(mirrorTree(node.right), mirrorTree(node.left))
		return mir

def allTrees(n):
	"""
	Returns a list of all unique trees with n internal nodes
	"""

	result = []
	#Takes care of end of recursion
	if(n==0):
		result.append(Node())
		return result
	
	#i ranges from 0 to (n-1); nth is the parent node
	for i in range(n):
		left_list = allTrees(i)
		right_list = allTrees(n-1-i)
		#append() mutates the list itself; appending the node to result[] itself. temp[] is completely filled with None
		temp = [result.append(Node(left_tree, right_tree)) for left_tree in left_list for right_tree in right_list]

	return result

def allSymTrees(n):
	"""
	Returns a list of all unique symmetrical trees with n internal nodes
	"""
	result = []
	#append leaf nodes at the end of the line
	if n==0:
		result.append(Node())
		return result

	#return empty list if n is even as no sym tree possible
	if n%2 == 0:
		return result

	#Divide into two equal parts, n is surely odd here
	half_len = (n-1)//2
	half_list = allTrees(half_len)
	temp = [result.append(Node(half_tree, mirrorTree(half_tree))) for half_tree in half_list]

	return result


if __name__ == '__main__':
	for x in allSymTrees(int(input())):
		print(x)
	node = Node(Node(Node(), Node()), Node())
	print(node)