from django.contrib import admin
from .models import Files

# Register your models here.
admin.site.register(Files)
