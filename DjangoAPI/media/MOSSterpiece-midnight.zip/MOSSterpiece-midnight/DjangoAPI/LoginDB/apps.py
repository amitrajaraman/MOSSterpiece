from django.apps import AppConfig


class LogindbConfig(AppConfig):
    name = 'LoginDB'
