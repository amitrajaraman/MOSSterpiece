export interface Contact {
    name: string;
    email: string;
    feedback: string;
    comment: string;
}